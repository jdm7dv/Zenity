﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace ZentityDataImport.Repository
{
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using Zentity.ScholarlyWorks;

    /// <summary>
    /// Interface for defining the logic to retreive documents/articles from various
    /// online repositories
    /// </summary>
    public interface IRepositoryAdapter
    {
        /// <summary>
        /// Fetches the documents and returns a collection of ResearchDocument objects
        /// </summary>
        /// <param name="parameterCollection">The parameter collection.</param>
        /// <returns>Collection of ResearchDocument objects</returns>
        IEnumerable<Journal> FetchDocuments(StringDictionary parameterCollection);
    }
}
