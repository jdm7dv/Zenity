﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace ZentityDataImport.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Globalization;
    using System.Linq;
    using Zentity.ScholarlyWorks;
    using ZentityDataImport.eFetchPubMed;

    /// <summary>
    /// Concrete implementation for the PubMed Online Repository
    /// </summary>
    internal class PubMedRepository : IRepositoryAdapter
    {
        #region IRepositoryAdapter Members

        /// <summary>
        /// Fetches the documents and returns a collection of ResearchDocument objects
        /// </summary>
        /// <param name="parameterCollection">A collection of parameters used for fetching data</param>
        /// <returns>Collection of ResearchDocument objects</returns>
        public IEnumerable<Journal> FetchDocuments(StringDictionary parameterCollection)
        {
            eUtils.eUtilsService eutilsService = new eUtils.eUtilsService();
            eUtils.eSearchRequest esearchRequest = new eUtils.eSearchRequest();
            
            esearchRequest.db = "pubmed";
            esearchRequest.sort = "PublicationDate";
            esearchRequest.term = parameterCollection["SearchTerm"];
            esearchRequest.RetMax = parameterCollection["RecordCount"];
            esearchRequest.usehistory = "y";

            eUtils.eSearchResult esearchResult = eutilsService.run_eSearch(esearchRequest);

            string queryKey = esearchResult.QueryKey;
            string webEnv = esearchResult.WebEnv;

            eFetchPubMed.eFetchPubmedService efetchService = new eFetchPubMed.eFetchPubmedService();
            eFetchPubMed.eFetchRequest efetchRequest = new eFetchPubMed.eFetchRequest();
            efetchRequest.WebEnv = webEnv;
            efetchRequest.query_key = queryKey;

            efetchRequest.retstart = "0";
            efetchRequest.retmax = parameterCollection["RecordCount"];
            eFetchPubMed.eFetchResult efetchResult = efetchService.run_eFetch(efetchRequest);

            Journal[] researchDocuments = new Journal[efetchResult.PubmedArticleSet.Length];
            for (int i = 0; i < efetchResult.PubmedArticleSet.Length; i++)
            {
                researchDocuments[i] = new Journal();
                
                if (efetchResult.PubmedArticleSet[i].MedlineCitation.Article != null)
                {
                    researchDocuments[i].Title = efetchResult.PubmedArticleSet[i].MedlineCitation.Article.ArticleTitle;
                    if (efetchResult.PubmedArticleSet[i].MedlineCitation.Article.Abstract != null)
                    {
                        researchDocuments[i].Abstract = efetchResult.PubmedArticleSet[i].MedlineCitation.Article.Abstract.AbstractText;
                        researchDocuments[i].License = efetchResult.PubmedArticleSet[i].MedlineCitation.Article.Abstract.CopyrightInformation;
                    }

                    researchDocuments[i].DatePublished = new DateTime(
                        Convert.ToInt32(efetchResult.PubmedArticleSet[i].MedlineCitation.DateCreated.Year, CultureInfo.InvariantCulture),
                        Convert.ToInt32(efetchResult.PubmedArticleSet[i].MedlineCitation.DateCreated.Month, CultureInfo.InvariantCulture),
                        Convert.ToInt32(efetchResult.PubmedArticleSet[i].MedlineCitation.DateCreated.Day, CultureInfo.InvariantCulture));

                    if (efetchResult.PubmedArticleSet[i].MedlineCitation.Article.AuthorList != null)
                    {
                        foreach (AuthorType auth in efetchResult.PubmedArticleSet[i].MedlineCitation.Article.AuthorList.Author)
                        {
                            Person documentAuthor = new Person();
                            
                            int indexFirstName = Array.FindIndex<ItemsChoiceType2>(auth.ItemsElementName, (arg => arg == ItemsChoiceType2.ForeName));
                            if (indexFirstName >= 0)
                            {
                                documentAuthor.FirstName = auth.Items[indexFirstName].ToString();
                            }
                            
                            int indexLastName = Array.FindIndex<ItemsChoiceType2>(auth.ItemsElementName, (arg => arg == ItemsChoiceType2.LastName));
                            if (indexLastName >= 0)
                            {
                                documentAuthor.LastName = auth.Items[indexLastName].ToString();
                            }

                            if (!(string.IsNullOrEmpty(documentAuthor.FirstName) && string.IsNullOrEmpty(documentAuthor.LastName)))
                            {
                                documentAuthor.Title = documentAuthor.FirstName + " " + documentAuthor.LastName;
                            }

                            researchDocuments[i].Authors.Add(documentAuthor);
                        }
                    }
                }
            }

            return researchDocuments.AsEnumerable<Journal>();
        }

        #endregion
    }
}
