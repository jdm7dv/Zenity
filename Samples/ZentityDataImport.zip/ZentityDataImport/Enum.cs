﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace ZentityDataImport
{
    /// <summary>
    /// Defines the different Repository Types
    /// </summary>
    public enum RepositoryType
    {
        /// <summary>
        /// PubMed Online Repository
        /// </summary>
        PubMedOnline,
        
        /// <summary>
        /// ArXiv Local Files
        /// </summary>
        ArXivLocal
    }
}