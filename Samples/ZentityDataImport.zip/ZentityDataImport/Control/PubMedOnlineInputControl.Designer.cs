﻿namespace ZentityDataImport.Control
{
    partial class PubMedOnlineInputControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ComboRecords = new System.Windows.Forms.ComboBox();
            this.TextSearch = new System.Windows.Forms.TextBox();
            this.LabelRecords = new System.Windows.Forms.Label();
            this.LabelSearch = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ComboRecords
            // 
            this.ComboRecords.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboRecords.FormattingEnabled = true;
            this.ComboRecords.Items.AddRange(new object[] {
            "5",
            "10",
            "25",
            "50",
            "100",
            "500",
            "1000",
            "5000"});
            this.ComboRecords.Location = new System.Drawing.Point(145, 44);
            this.ComboRecords.Name = "ComboRecords";
            this.ComboRecords.Size = new System.Drawing.Size(49, 21);
            this.ComboRecords.TabIndex = 9;
            // 
            // TextSearch
            // 
            this.TextSearch.Location = new System.Drawing.Point(145, 0);
            this.TextSearch.Name = "TextSearch";
            this.TextSearch.Size = new System.Drawing.Size(241, 20);
            this.TextSearch.TabIndex = 8;
            // 
            // LabelRecords
            // 
            this.LabelRecords.AutoSize = true;
            this.LabelRecords.Location = new System.Drawing.Point(0, 48);
            this.LabelRecords.Name = "LabelRecords";
            this.LabelRecords.Size = new System.Drawing.Size(89, 13);
            this.LabelRecords.TabIndex = 7;
            this.LabelRecords.Text = "Records to Fetch";
            // 
            // LabelSearch
            // 
            this.LabelSearch.AutoSize = true;
            this.LabelSearch.Location = new System.Drawing.Point(0, 4);
            this.LabelSearch.Name = "LabelSearch";
            this.LabelSearch.Size = new System.Drawing.Size(96, 13);
            this.LabelSearch.TabIndex = 6;
            this.LabelSearch.Text = "Enter Search Term";
            // 
            // PubMedOnlineInputControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ComboRecords);
            this.Controls.Add(this.TextSearch);
            this.Controls.Add(this.LabelRecords);
            this.Controls.Add(this.LabelSearch);
            this.Name = "PubMedOnlineInputControl";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ComboRecords;
        private System.Windows.Forms.TextBox TextSearch;
        private System.Windows.Forms.Label LabelRecords;
        private System.Windows.Forms.Label LabelSearch;
    }
}
