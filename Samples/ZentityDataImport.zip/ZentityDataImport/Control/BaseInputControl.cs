﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace ZentityDataImport.Control
{
    using System.Collections.Specialized;
    using System.Windows.Forms;

    /// <summary>
    /// Defines the base class for the repository input user controls
    /// </summary>
    public partial class BaseInputControl : UserControl
    {
        /// <summary>
        /// Parameters to be passed to the control consumer
        /// </summary>
        private StringDictionary dataParameters = new StringDictionary();

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseInputControl"/> class.
        /// </summary>
        public BaseInputControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Gets the parameters.
        /// </summary>
        /// <value>The parameters.</value>
        public virtual StringDictionary Parameters
        {
            get
            {
                return this.dataParameters;
            }
        }

        /// <summary>
        /// Validates the inputs.
        /// </summary>
        /// <returns>returns true if validation passes, otherwise false</returns>
        public virtual bool ValidateInputs()
        {
            return true;
        }
    }
}
