﻿namespace ZentityDataImport.Control
{
    partial class ArXivLocalInputControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ComboRecords = new System.Windows.Forms.ComboBox();
            this.TextSearchPath = new System.Windows.Forms.TextBox();
            this.LabelRecords = new System.Windows.Forms.Label();
            this.LabelSearchPath = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ComboRecords
            // 
            this.ComboRecords.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboRecords.FormattingEnabled = true;
            this.ComboRecords.Items.AddRange(new object[] {
            "5",
            "10",
            "25",
            "50",
            "ALL"});
            this.ComboRecords.Location = new System.Drawing.Point(145, 44);
            this.ComboRecords.Name = "ComboRecords";
            this.ComboRecords.Size = new System.Drawing.Size(49, 21);
            this.ComboRecords.TabIndex = 9;
            // 
            // TextSearchPath
            // 
            this.TextSearchPath.Location = new System.Drawing.Point(145, 0);
            this.TextSearchPath.Name = "TextSearchPath";
            this.TextSearchPath.Size = new System.Drawing.Size(241, 20);
            this.TextSearchPath.TabIndex = 8;
            // 
            // LabelRecords
            // 
            this.LabelRecords.AutoSize = true;
            this.LabelRecords.Location = new System.Drawing.Point(0, 48);
            this.LabelRecords.Name = "LabelRecords";
            this.LabelRecords.Size = new System.Drawing.Size(89, 13);
            this.LabelRecords.TabIndex = 7;
            this.LabelRecords.Text = "Records to Fetch";
            // 
            // LabelSearchPath
            // 
            this.LabelSearchPath.AutoSize = true;
            this.LabelSearchPath.Location = new System.Drawing.Point(0, 4);
            this.LabelSearchPath.Name = "LabelSearchPath";
            this.LabelSearchPath.Size = new System.Drawing.Size(100, 13);
            this.LabelSearchPath.TabIndex = 6;
            this.LabelSearchPath.Text = "ArXiv Files Location";
            // 
            // ArXivLocalInputControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ComboRecords);
            this.Controls.Add(this.TextSearchPath);
            this.Controls.Add(this.LabelRecords);
            this.Controls.Add(this.LabelSearchPath);
            this.Name = "ArXivLocalInputControl";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ComboRecords;
        private System.Windows.Forms.TextBox TextSearchPath;
        private System.Windows.Forms.Label LabelRecords;
        private System.Windows.Forms.Label LabelSearchPath;
    }
}
