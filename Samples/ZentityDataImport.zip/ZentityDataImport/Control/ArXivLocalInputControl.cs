﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace ZentityDataImport.Control
{
    using System.Collections.Specialized;
    using System.Windows.Forms;

    /// <summary>
    /// Defines the class for the repository input user controls for PubMed Online
    /// </summary>
    public partial class ArXivLocalInputControl : BaseInputControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ArXivLocalInputControl"/> class.
        /// </summary>
        public ArXivLocalInputControl()
        {
            InitializeComponent();
            this.ComboRecords.SelectedItem = "5";
        }

        /// <summary>
        /// Gets the parameters.
        /// </summary>
        /// <value>The parameters.</value>
        public override StringDictionary Parameters
        {
            get
            {
                if (base.Parameters.ContainsKey("SearchPath"))
                {
                    base.Parameters["SearchPath"] = this.TextSearchPath.Text.Trim();
                }
                else
                {
                    base.Parameters.Add("SearchPath", this.TextSearchPath.Text.Trim());
                }

                if (base.Parameters.ContainsKey("RecordCount"))
                {
                    base.Parameters["RecordCount"] = this.ComboRecords.SelectedItem.ToString();
                }
                else
                {
                    base.Parameters.Add("RecordCount", this.ComboRecords.SelectedItem.ToString());
                }

                return base.Parameters;
            }
        }

        /// <summary>
        /// Validates the inputs.
        /// </summary>
        /// <returns>returns true if validation passes, otherwise false</returns>
        public override bool ValidateInputs()
        {
            if (string.IsNullOrEmpty(this.TextSearchPath.Text.Trim()))
            {
                MessageBox.Show("Enter the path of the ArXiv files");
                return false;
            }

            if (this.ComboRecords.SelectedIndex < 0)
            {
                MessageBox.Show("Select the number of records to fetch");
                return false;
            }

            return true;
        }
    }
}
