﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************

#pragma warning disable 1591

namespace ZentityDataImport.eFetchPubMed {
    using System;
    using System.Web.Services;
    using System.Diagnostics;
    using System.Web.Services.Protocols;
    using System.ComponentModel;
    using System.Xml.Serialization;
    
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Web.Services.WebServiceBindingAttribute(Name="eUtilsServiceSoap", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/")]
    public partial class eFetchPubmedService : System.Web.Services.Protocols.SoapHttpClientProtocol {
        
        private System.Threading.SendOrPostCallback run_eFetchOperationCompleted;
        
        private bool useDefaultCredentialsSetExplicitly;
        
        /// <remarks/>
        public eFetchPubmedService() {
            this.Url = global::ZentityDataImport.Properties.Settings.Default.ZentityDataImport_eFetchPubMed_eFetchPubmedService;
            if ((this.IsLocalFileSystemWebService(this.Url) == true)) {
                this.UseDefaultCredentials = true;
                this.useDefaultCredentialsSetExplicitly = false;
            }
            else {
                this.useDefaultCredentialsSetExplicitly = true;
            }
        }
        
        public new string Url {
            get {
                return base.Url;
            }
            set {
                if ((((this.IsLocalFileSystemWebService(base.Url) == true) 
                            && (this.useDefaultCredentialsSetExplicitly == false)) 
                            && (this.IsLocalFileSystemWebService(value) == false))) {
                    base.UseDefaultCredentials = false;
                }
                base.Url = value;
            }
        }
        
        public new bool UseDefaultCredentials {
            get {
                return base.UseDefaultCredentials;
            }
            set {
                base.UseDefaultCredentials = value;
                this.useDefaultCredentialsSetExplicitly = true;
            }
        }
        
        /// <remarks/>
        public event run_eFetchCompletedEventHandler run_eFetchCompleted;
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("efetch", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("eFetchResult", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
        public eFetchResult run_eFetch([System.Xml.Serialization.XmlElementAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")] eFetchRequest eFetchRequest) {
            object[] results = this.Invoke("run_eFetch", new object[] {
                        eFetchRequest});
            return ((eFetchResult)(results[0]));
        }
        
        /// <remarks/>
        public void run_eFetchAsync(eFetchRequest eFetchRequest) {
            this.run_eFetchAsync(eFetchRequest, null);
        }
        
        /// <remarks/>
        public void run_eFetchAsync(eFetchRequest eFetchRequest, object userState) {
            if ((this.run_eFetchOperationCompleted == null)) {
                this.run_eFetchOperationCompleted = new System.Threading.SendOrPostCallback(this.Onrun_eFetchOperationCompleted);
            }
            this.InvokeAsync("run_eFetch", new object[] {
                        eFetchRequest}, this.run_eFetchOperationCompleted, userState);
        }
        
        private void Onrun_eFetchOperationCompleted(object arg) {
            if ((this.run_eFetchCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.run_eFetchCompleted(this, new run_eFetchCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        public new void CancelAsync(object userState) {
            base.CancelAsync(userState);
        }
        
        private bool IsLocalFileSystemWebService(string url) {
            if (((url == null) 
                        || (url == string.Empty))) {
                return false;
            }
            System.Uri wsUri = new System.Uri(url);
            if (((wsUri.Port >= 1024) 
                        && (string.Compare(wsUri.Host, "localHost", System.StringComparison.OrdinalIgnoreCase) == 0))) {
                return true;
            }
            return false;
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class eFetchRequest {
        
        private string idField;
        
        private string webEnvField;
        
        private string query_keyField;
        
        private string toolField;
        
        private string emailField;
        
        private string retstartField;
        
        private string retmaxField;
        
        private string rettypeField;
        
        /// <remarks/>
        public string id {
            get {
                return this.idField;
            }
            set {
                this.idField = value;
            }
        }
        
        /// <remarks/>
        public string WebEnv {
            get {
                return this.webEnvField;
            }
            set {
                this.webEnvField = value;
            }
        }
        
        /// <remarks/>
        public string query_key {
            get {
                return this.query_keyField;
            }
            set {
                this.query_keyField = value;
            }
        }
        
        /// <remarks/>
        public string tool {
            get {
                return this.toolField;
            }
            set {
                this.toolField = value;
            }
        }
        
        /// <remarks/>
        public string email {
            get {
                return this.emailField;
            }
            set {
                this.emailField = value;
            }
        }
        
        /// <remarks/>
        public string retstart {
            get {
                return this.retstartField;
            }
            set {
                this.retstartField = value;
            }
        }
        
        /// <remarks/>
        public string retmax {
            get {
                return this.retmaxField;
            }
            set {
                this.retmaxField = value;
            }
        }
        
        /// <remarks/>
        public string rettype {
            get {
                return this.rettypeField;
            }
            set {
                this.rettypeField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class ParamType {
        
        private string nameField;
        
        private string valueField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Name {
            get {
                return this.nameField;
            }
            set {
                this.nameField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class ObjectType {
        
        private ParamType[] paramField;
        
        private string typeField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Param")]
        public ParamType[] Param {
            get {
                return this.paramField;
            }
            set {
                this.paramField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Type {
            get {
                return this.typeField;
            }
            set {
                this.typeField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class ObjectListType {
        
        private ObjectType[] objectField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Object")]
        public ObjectType[] Object {
            get {
                return this.objectField;
            }
            set {
                this.objectField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class ArticleIdType {
        
        private ArticleIdTypeIdType idTypeField;
        
        private string valueField;
        
        public ArticleIdType() {
            this.idTypeField = ArticleIdTypeIdType.pubmed;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(ArticleIdTypeIdType.pubmed)]
        public ArticleIdTypeIdType IdType {
            get {
                return this.idTypeField;
            }
            set {
                this.idTypeField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum ArticleIdTypeIdType {
        
        /// <remarks/>
        doi,
        
        /// <remarks/>
        pii,
        
        /// <remarks/>
        pmcpid,
        
        /// <remarks/>
        pmpid,
        
        /// <remarks/>
        pmc,
        
        /// <remarks/>
        mid,
        
        /// <remarks/>
        sici,
        
        /// <remarks/>
        pubmed,
        
        /// <remarks/>
        medline,
        
        /// <remarks/>
        pmcid,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class PubMedPubDateType {
        
        private string yearField;
        
        private string monthField;
        
        private string dayField;
        
        private string hourField;
        
        private string minuteField;
        
        private string secondField;
        
        private PubMedPubDateTypePubStatus pubStatusField;
        
        /// <remarks/>
        public string Year {
            get {
                return this.yearField;
            }
            set {
                this.yearField = value;
            }
        }
        
        /// <remarks/>
        public string Month {
            get {
                return this.monthField;
            }
            set {
                this.monthField = value;
            }
        }
        
        /// <remarks/>
        public string Day {
            get {
                return this.dayField;
            }
            set {
                this.dayField = value;
            }
        }
        
        /// <remarks/>
        public string Hour {
            get {
                return this.hourField;
            }
            set {
                this.hourField = value;
            }
        }
        
        /// <remarks/>
        public string Minute {
            get {
                return this.minuteField;
            }
            set {
                this.minuteField = value;
            }
        }
        
        /// <remarks/>
        public string Second {
            get {
                return this.secondField;
            }
            set {
                this.secondField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public PubMedPubDateTypePubStatus PubStatus {
            get {
                return this.pubStatusField;
            }
            set {
                this.pubStatusField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum PubMedPubDateTypePubStatus {
        
        /// <remarks/>
        received,
        
        /// <remarks/>
        accepted,
        
        /// <remarks/>
        epublish,
        
        /// <remarks/>
        ppublish,
        
        /// <remarks/>
        revised,
        
        /// <remarks/>
        aheadofprint,
        
        /// <remarks/>
        retracted,
        
        /// <remarks/>
        pmc,
        
        /// <remarks/>
        pmcr,
        
        /// <remarks/>
        pubmed,
        
        /// <remarks/>
        pubmedr,
        
        /// <remarks/>
        premedline,
        
        /// <remarks/>
        medline,
        
        /// <remarks/>
        medliner,
        
        /// <remarks/>
        entrez,
        
        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("pmc-release")]
        pmcrelease,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class PubmedDataType {
        
        private PubMedPubDateType[] historyField;
        
        private string publicationStatusField;
        
        private ArticleIdType[] articleIdListField;
        
        private ObjectListType objectListField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("PubMedPubDate", IsNullable=false)]
        public PubMedPubDateType[] History {
            get {
                return this.historyField;
            }
            set {
                this.historyField = value;
            }
        }
        
        /// <remarks/>
        public string PublicationStatus {
            get {
                return this.publicationStatusField;
            }
            set {
                this.publicationStatusField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("ArticleId", IsNullable=false)]
        public ArticleIdType[] ArticleIdList {
            get {
                return this.articleIdListField;
            }
            set {
                this.articleIdListField = value;
            }
        }
        
        /// <remarks/>
        public ObjectListType ObjectList {
            get {
                return this.objectListField;
            }
            set {
                this.objectListField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class GeneralNoteType {
        
        private GeneralNoteTypeOwner ownerField;
        
        private string valueField;
        
        public GeneralNoteType() {
            this.ownerField = GeneralNoteTypeOwner.NLM;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(GeneralNoteTypeOwner.NLM)]
        public GeneralNoteTypeOwner Owner {
            get {
                return this.ownerField;
            }
            set {
                this.ownerField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum GeneralNoteTypeOwner {
        
        /// <remarks/>
        NLM,
        
        /// <remarks/>
        NASA,
        
        /// <remarks/>
        PIP,
        
        /// <remarks/>
        KIE,
        
        /// <remarks/>
        HSR,
        
        /// <remarks/>
        HMD,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class InvestigatorType {
        
        private string lastNameField;
        
        private string foreNameField;
        
        private string initialsField;
        
        private string suffixField;
        
        private NameIDType[] nameIDField;
        
        private string affiliationField;
        
        private InvestigatorTypeValidYN validYNField;
        
        public InvestigatorType() {
            this.validYNField = InvestigatorTypeValidYN.Y;
        }
        
        /// <remarks/>
        public string LastName {
            get {
                return this.lastNameField;
            }
            set {
                this.lastNameField = value;
            }
        }
        
        /// <remarks/>
        public string ForeName {
            get {
                return this.foreNameField;
            }
            set {
                this.foreNameField = value;
            }
        }
        
        /// <remarks/>
        public string Initials {
            get {
                return this.initialsField;
            }
            set {
                this.initialsField = value;
            }
        }
        
        /// <remarks/>
        public string Suffix {
            get {
                return this.suffixField;
            }
            set {
                this.suffixField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("NameID")]
        public NameIDType[] NameID {
            get {
                return this.nameIDField;
            }
            set {
                this.nameIDField = value;
            }
        }
        
        /// <remarks/>
        public string Affiliation {
            get {
                return this.affiliationField;
            }
            set {
                this.affiliationField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(InvestigatorTypeValidYN.Y)]
        public InvestigatorTypeValidYN ValidYN {
            get {
                return this.validYNField;
            }
            set {
                this.validYNField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class NameIDType {
        
        private NameIDTypeSource sourceField;
        
        private string valueField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public NameIDTypeSource Source {
            get {
                return this.sourceField;
            }
            set {
                this.sourceField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum NameIDTypeSource {
        
        /// <remarks/>
        NCBI,
        
        /// <remarks/>
        Publisher,
        
        /// <remarks/>
        NISO,
        
        /// <remarks/>
        ISO,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum InvestigatorTypeValidYN {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class KeywordType {
        
        private KeywordTypeMajorTopicYN majorTopicYNField;
        
        private string valueField;
        
        public KeywordType() {
            this.majorTopicYNField = KeywordTypeMajorTopicYN.N;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(KeywordTypeMajorTopicYN.N)]
        public KeywordTypeMajorTopicYN MajorTopicYN {
            get {
                return this.majorTopicYNField;
            }
            set {
                this.majorTopicYNField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum KeywordTypeMajorTopicYN {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class KeywordListType {
        
        private KeywordType[] keywordField;
        
        private KeywordListTypeOwner ownerField;
        
        public KeywordListType() {
            this.ownerField = KeywordListTypeOwner.NLM;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Keyword")]
        public KeywordType[] Keyword {
            get {
                return this.keywordField;
            }
            set {
                this.keywordField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(KeywordListTypeOwner.NLM)]
        public KeywordListTypeOwner Owner {
            get {
                return this.ownerField;
            }
            set {
                this.ownerField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum KeywordListTypeOwner {
        
        /// <remarks/>
        NLM,
        
        /// <remarks/>
        NASA,
        
        /// <remarks/>
        PIP,
        
        /// <remarks/>
        KIE,
        
        /// <remarks/>
        NOTNLM,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class OtherAbstractType {
        
        private string abstractTextField;
        
        private string copyrightInformationField;
        
        private OtherAbstractTypeType typeField;
        
        /// <remarks/>
        public string AbstractText {
            get {
                return this.abstractTextField;
            }
            set {
                this.abstractTextField = value;
            }
        }
        
        /// <remarks/>
        public string CopyrightInformation {
            get {
                return this.copyrightInformationField;
            }
            set {
                this.copyrightInformationField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public OtherAbstractTypeType Type {
            get {
                return this.typeField;
            }
            set {
                this.typeField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum OtherAbstractTypeType {
        
        /// <remarks/>
        AAMC,
        
        /// <remarks/>
        AIDS,
        
        /// <remarks/>
        KIE,
        
        /// <remarks/>
        PIP,
        
        /// <remarks/>
        NASA,
        
        /// <remarks/>
        Publisher,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class OtherIDType {
        
        private OtherIDTypeSource sourceField;
        
        private string valueField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public OtherIDTypeSource Source {
            get {
                return this.sourceField;
            }
            set {
                this.sourceField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum OtherIDTypeSource {
        
        /// <remarks/>
        NASA,
        
        /// <remarks/>
        KIE,
        
        /// <remarks/>
        PIP,
        
        /// <remarks/>
        POP,
        
        /// <remarks/>
        ARPL,
        
        /// <remarks/>
        CPC,
        
        /// <remarks/>
        IND,
        
        /// <remarks/>
        CPFH,
        
        /// <remarks/>
        CLML,
        
        /// <remarks/>
        NRCBL,
        
        /// <remarks/>
        NLM,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class PersonalNameSubjectType {
        
        private string lastNameField;
        
        private string foreNameField;
        
        private string initialsField;
        
        private string suffixField;
        
        /// <remarks/>
        public string LastName {
            get {
                return this.lastNameField;
            }
            set {
                this.lastNameField = value;
            }
        }
        
        /// <remarks/>
        public string ForeName {
            get {
                return this.foreNameField;
            }
            set {
                this.foreNameField = value;
            }
        }
        
        /// <remarks/>
        public string Initials {
            get {
                return this.initialsField;
            }
            set {
                this.initialsField = value;
            }
        }
        
        /// <remarks/>
        public string Suffix {
            get {
                return this.suffixField;
            }
            set {
                this.suffixField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class QualifierNameType {
        
        private QualifierNameTypeMajorTopicYN majorTopicYNField;
        
        private string valueField;
        
        public QualifierNameType() {
            this.majorTopicYNField = QualifierNameTypeMajorTopicYN.N;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(QualifierNameTypeMajorTopicYN.N)]
        public QualifierNameTypeMajorTopicYN MajorTopicYN {
            get {
                return this.majorTopicYNField;
            }
            set {
                this.majorTopicYNField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum QualifierNameTypeMajorTopicYN {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class DescriptorNameType {
        
        private DescriptorNameTypeMajorTopicYN majorTopicYNField;
        
        private string valueField;
        
        public DescriptorNameType() {
            this.majorTopicYNField = DescriptorNameTypeMajorTopicYN.N;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(DescriptorNameTypeMajorTopicYN.N)]
        public DescriptorNameTypeMajorTopicYN MajorTopicYN {
            get {
                return this.majorTopicYNField;
            }
            set {
                this.majorTopicYNField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum DescriptorNameTypeMajorTopicYN {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class MeshHeadingType {
        
        private DescriptorNameType descriptorNameField;
        
        private QualifierNameType[] qualifierNameField;
        
        /// <remarks/>
        public DescriptorNameType DescriptorName {
            get {
                return this.descriptorNameField;
            }
            set {
                this.descriptorNameField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("QualifierName")]
        public QualifierNameType[] QualifierName {
            get {
                return this.qualifierNameField;
            }
            set {
                this.qualifierNameField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class CommentsCorrectionsType {
        
        private string refSourceField;
        
        private string pMIDField;
        
        private string noteField;
        
        private CommentsCorrectionsTypeRefType refTypeField;
        
        /// <remarks/>
        public string RefSource {
            get {
                return this.refSourceField;
            }
            set {
                this.refSourceField = value;
            }
        }
        
        /// <remarks/>
        public string PMID {
            get {
                return this.pMIDField;
            }
            set {
                this.pMIDField = value;
            }
        }
        
        /// <remarks/>
        public string Note {
            get {
                return this.noteField;
            }
            set {
                this.noteField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public CommentsCorrectionsTypeRefType RefType {
            get {
                return this.refTypeField;
            }
            set {
                this.refTypeField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum CommentsCorrectionsTypeRefType {
        
        /// <remarks/>
        CommentOn,
        
        /// <remarks/>
        CommentIn,
        
        /// <remarks/>
        ErratumIn,
        
        /// <remarks/>
        ErratumFor,
        
        /// <remarks/>
        PartialRetractionIn,
        
        /// <remarks/>
        PartialRetractionOf,
        
        /// <remarks/>
        RepublishedFrom,
        
        /// <remarks/>
        RepublishedIn,
        
        /// <remarks/>
        RetractionOf,
        
        /// <remarks/>
        RetractionIn,
        
        /// <remarks/>
        UpdateIn,
        
        /// <remarks/>
        UpdateOf,
        
        /// <remarks/>
        SummaryForPatientsIn,
        
        /// <remarks/>
        OriginalReportIn,
        
        /// <remarks/>
        ReprintOf,
        
        /// <remarks/>
        ReprintIn,
        
        /// <remarks/>
        Cites,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class ChemicalType {
        
        private string registryNumberField;
        
        private string nameOfSubstanceField;
        
        /// <remarks/>
        public string RegistryNumber {
            get {
                return this.registryNumberField;
            }
            set {
                this.registryNumberField = value;
            }
        }
        
        /// <remarks/>
        public string NameOfSubstance {
            get {
                return this.nameOfSubstanceField;
            }
            set {
                this.nameOfSubstanceField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class MedlineJournalInfoType {
        
        private string countryField;
        
        private string medlineTAField;
        
        private string nlmUniqueIDField;
        
        private string iSSNLinkingField;
        
        /// <remarks/>
        public string Country {
            get {
                return this.countryField;
            }
            set {
                this.countryField = value;
            }
        }
        
        /// <remarks/>
        public string MedlineTA {
            get {
                return this.medlineTAField;
            }
            set {
                this.medlineTAField = value;
            }
        }
        
        /// <remarks/>
        public string NlmUniqueID {
            get {
                return this.nlmUniqueIDField;
            }
            set {
                this.nlmUniqueIDField = value;
            }
        }
        
        /// <remarks/>
        public string ISSNLinking {
            get {
                return this.iSSNLinkingField;
            }
            set {
                this.iSSNLinkingField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class ArticleDateType {
        
        private string yearField;
        
        private string monthField;
        
        private string dayField;
        
        private string dateTypeField;
        
        public ArticleDateType() {
            this.dateTypeField = "Electronic";
        }
        
        /// <remarks/>
        public string Year {
            get {
                return this.yearField;
            }
            set {
                this.yearField = value;
            }
        }
        
        /// <remarks/>
        public string Month {
            get {
                return this.monthField;
            }
            set {
                this.monthField = value;
            }
        }
        
        /// <remarks/>
        public string Day {
            get {
                return this.dayField;
            }
            set {
                this.dayField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string DateType {
            get {
                return this.dateTypeField;
            }
            set {
                this.dateTypeField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class GrantType {
        
        private string grantIDField;
        
        private string acronymField;
        
        private string agencyField;
        
        private string countryField;
        
        /// <remarks/>
        public string GrantID {
            get {
                return this.grantIDField;
            }
            set {
                this.grantIDField = value;
            }
        }
        
        /// <remarks/>
        public string Acronym {
            get {
                return this.acronymField;
            }
            set {
                this.acronymField = value;
            }
        }
        
        /// <remarks/>
        public string Agency {
            get {
                return this.agencyField;
            }
            set {
                this.agencyField = value;
            }
        }
        
        /// <remarks/>
        public string Country {
            get {
                return this.countryField;
            }
            set {
                this.countryField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class GrantListType {
        
        private GrantType[] grantField;
        
        private GrantListTypeCompleteYN completeYNField;
        
        public GrantListType() {
            this.completeYNField = GrantListTypeCompleteYN.Y;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Grant")]
        public GrantType[] Grant {
            get {
                return this.grantField;
            }
            set {
                this.grantField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(GrantListTypeCompleteYN.Y)]
        public GrantListTypeCompleteYN CompleteYN {
            get {
                return this.completeYNField;
            }
            set {
                this.completeYNField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum GrantListTypeCompleteYN {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class DataBankType {
        
        private string dataBankNameField;
        
        private string[] accessionNumberListField;
        
        /// <remarks/>
        public string DataBankName {
            get {
                return this.dataBankNameField;
            }
            set {
                this.dataBankNameField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("AccessionNumber", IsNullable=false)]
        public string[] AccessionNumberList {
            get {
                return this.accessionNumberListField;
            }
            set {
                this.accessionNumberListField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class DataBankListType {
        
        private DataBankType[] dataBankField;
        
        private DataBankListTypeCompleteYN completeYNField;
        
        public DataBankListType() {
            this.completeYNField = DataBankListTypeCompleteYN.Y;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("DataBank")]
        public DataBankType[] DataBank {
            get {
                return this.dataBankField;
            }
            set {
                this.dataBankField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(DataBankListTypeCompleteYN.Y)]
        public DataBankListTypeCompleteYN CompleteYN {
            get {
                return this.completeYNField;
            }
            set {
                this.completeYNField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum DataBankListTypeCompleteYN {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class AuthorType {
        
        private object[] itemsField;
        
        private ItemsChoiceType2[] itemsElementNameField;
        
        private AuthorTypeValidYN validYNField;
        
        public AuthorType() {
            this.validYNField = AuthorTypeValidYN.Y;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("CollectiveName", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("ForeName", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("Initials", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("LastName", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("NameID", typeof(NameIDType))]
        [System.Xml.Serialization.XmlElementAttribute("Suffix", typeof(string))]
        [System.Xml.Serialization.XmlChoiceIdentifierAttribute("ItemsElementName")]
        public object[] Items {
            get {
                return this.itemsField;
            }
            set {
                this.itemsField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ItemsElementName")]
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public ItemsChoiceType2[] ItemsElementName {
            get {
                return this.itemsElementNameField;
            }
            set {
                this.itemsElementNameField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(AuthorTypeValidYN.Y)]
        public AuthorTypeValidYN ValidYN {
            get {
                return this.validYNField;
            }
            set {
                this.validYNField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed", IncludeInSchema=false)]
    public enum ItemsChoiceType2 {
        
        /// <remarks/>
        CollectiveName,
        
        /// <remarks/>
        ForeName,
        
        /// <remarks/>
        Initials,
        
        /// <remarks/>
        LastName,
        
        /// <remarks/>
        NameID,
        
        /// <remarks/>
        Suffix,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum AuthorTypeValidYN {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class AuthorListType {
        
        private AuthorType[] authorField;
        
        private AuthorListTypeCompleteYN completeYNField;
        
        public AuthorListType() {
            this.completeYNField = AuthorListTypeCompleteYN.Y;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Author")]
        public AuthorType[] Author {
            get {
                return this.authorField;
            }
            set {
                this.authorField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(AuthorListTypeCompleteYN.Y)]
        public AuthorListTypeCompleteYN CompleteYN {
            get {
                return this.completeYNField;
            }
            set {
                this.completeYNField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum AuthorListTypeCompleteYN {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class AbstractType {
        
        private string abstractTextField;
        
        private string copyrightInformationField;
        
        /// <remarks/>
        public string AbstractText {
            get {
                return this.abstractTextField;
            }
            set {
                this.abstractTextField = value;
            }
        }
        
        /// <remarks/>
        public string CopyrightInformation {
            get {
                return this.copyrightInformationField;
            }
            set {
                this.copyrightInformationField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class ELocationIDType {
        
        private ELocationIDTypeEIdType eIdTypeField;
        
        private ELocationIDTypeValidYN validYNField;
        
        private string valueField;
        
        public ELocationIDType() {
            this.validYNField = ELocationIDTypeValidYN.Y;
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public ELocationIDTypeEIdType EIdType {
            get {
                return this.eIdTypeField;
            }
            set {
                this.eIdTypeField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(ELocationIDTypeValidYN.Y)]
        public ELocationIDTypeValidYN ValidYN {
            get {
                return this.validYNField;
            }
            set {
                this.validYNField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum ELocationIDTypeEIdType {
        
        /// <remarks/>
        doi,
        
        /// <remarks/>
        pii,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum ELocationIDTypeValidYN {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class PaginationType {
        
        private string[] itemsField;
        
        private ItemsChoiceType1[] itemsElementNameField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("EndPage", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("MedlinePgn", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("StartPage", typeof(string))]
        [System.Xml.Serialization.XmlChoiceIdentifierAttribute("ItemsElementName")]
        public string[] Items {
            get {
                return this.itemsField;
            }
            set {
                this.itemsField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ItemsElementName")]
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public ItemsChoiceType1[] ItemsElementName {
            get {
                return this.itemsElementNameField;
            }
            set {
                this.itemsElementNameField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed", IncludeInSchema=false)]
    public enum ItemsChoiceType1 {
        
        /// <remarks/>
        EndPage,
        
        /// <remarks/>
        MedlinePgn,
        
        /// <remarks/>
        StartPage,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class PubDateType {
        
        private string[] itemsField;
        
        private ItemsChoiceType[] itemsElementNameField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Day", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("MedlineDate", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("Month", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("Season", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("Year", typeof(string))]
        [System.Xml.Serialization.XmlChoiceIdentifierAttribute("ItemsElementName")]
        public string[] Items {
            get {
                return this.itemsField;
            }
            set {
                this.itemsField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ItemsElementName")]
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public ItemsChoiceType[] ItemsElementName {
            get {
                return this.itemsElementNameField;
            }
            set {
                this.itemsElementNameField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed", IncludeInSchema=false)]
    public enum ItemsChoiceType {
        
        /// <remarks/>
        Day,
        
        /// <remarks/>
        MedlineDate,
        
        /// <remarks/>
        Month,
        
        /// <remarks/>
        Season,
        
        /// <remarks/>
        Year,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class JournalIssueType {
        
        private string volumeField;
        
        private string issueField;
        
        private PubDateType pubDateField;
        
        private JournalIssueTypeCitedMedium citedMediumField;
        
        /// <remarks/>
        public string Volume {
            get {
                return this.volumeField;
            }
            set {
                this.volumeField = value;
            }
        }
        
        /// <remarks/>
        public string Issue {
            get {
                return this.issueField;
            }
            set {
                this.issueField = value;
            }
        }
        
        /// <remarks/>
        public PubDateType PubDate {
            get {
                return this.pubDateField;
            }
            set {
                this.pubDateField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public JournalIssueTypeCitedMedium CitedMedium {
            get {
                return this.citedMediumField;
            }
            set {
                this.citedMediumField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum JournalIssueTypeCitedMedium {
        
        /// <remarks/>
        Internet,
        
        /// <remarks/>
        Print,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class ISSNType {
        
        private ISSNTypeIssnType issnTypeField;
        
        private string valueField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public ISSNTypeIssnType IssnType {
            get {
                return this.issnTypeField;
            }
            set {
                this.issnTypeField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum ISSNTypeIssnType {
        
        /// <remarks/>
        Electronic,
        
        /// <remarks/>
        Print,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class JournalType {
        
        private ISSNType iSSNField;
        
        private JournalIssueType journalIssueField;
        
        private string titleField;
        
        private string iSOAbbreviationField;
        
        /// <remarks/>
        public ISSNType ISSN {
            get {
                return this.iSSNField;
            }
            set {
                this.iSSNField = value;
            }
        }
        
        /// <remarks/>
        public JournalIssueType JournalIssue {
            get {
                return this.journalIssueField;
            }
            set {
                this.journalIssueField = value;
            }
        }
        
        /// <remarks/>
        public string Title {
            get {
                return this.titleField;
            }
            set {
                this.titleField = value;
            }
        }
        
        /// <remarks/>
        public string ISOAbbreviation {
            get {
                return this.iSOAbbreviationField;
            }
            set {
                this.iSOAbbreviationField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class ArticleType {
        
        private JournalType journalField;
        
        private string articleTitleField;
        
        private object[] itemsField;
        
        private AbstractType abstractField;
        
        private string affiliationField;
        
        private AuthorListType authorListField;
        
        private string[] languageField;
        
        private DataBankListType dataBankListField;
        
        private GrantListType grantListField;
        
        private string[] publicationTypeListField;
        
        private string vernacularTitleField;
        
        private ArticleDateType[] articleDateField;
        
        private ArticleTypePubModel pubModelField;
        
        /// <remarks/>
        public JournalType Journal {
            get {
                return this.journalField;
            }
            set {
                this.journalField = value;
            }
        }
        
        /// <remarks/>
        public string ArticleTitle {
            get {
                return this.articleTitleField;
            }
            set {
                this.articleTitleField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ELocationID", typeof(ELocationIDType))]
        [System.Xml.Serialization.XmlElementAttribute("Pagination", typeof(PaginationType))]
        public object[] Items {
            get {
                return this.itemsField;
            }
            set {
                this.itemsField = value;
            }
        }
        
        /// <remarks/>
        public AbstractType Abstract {
            get {
                return this.abstractField;
            }
            set {
                this.abstractField = value;
            }
        }
        
        /// <remarks/>
        public string Affiliation {
            get {
                return this.affiliationField;
            }
            set {
                this.affiliationField = value;
            }
        }
        
        /// <remarks/>
        public AuthorListType AuthorList {
            get {
                return this.authorListField;
            }
            set {
                this.authorListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Language")]
        public string[] Language {
            get {
                return this.languageField;
            }
            set {
                this.languageField = value;
            }
        }
        
        /// <remarks/>
        public DataBankListType DataBankList {
            get {
                return this.dataBankListField;
            }
            set {
                this.dataBankListField = value;
            }
        }
        
        /// <remarks/>
        public GrantListType GrantList {
            get {
                return this.grantListField;
            }
            set {
                this.grantListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("PublicationType", IsNullable=false)]
        public string[] PublicationTypeList {
            get {
                return this.publicationTypeListField;
            }
            set {
                this.publicationTypeListField = value;
            }
        }
        
        /// <remarks/>
        public string VernacularTitle {
            get {
                return this.vernacularTitleField;
            }
            set {
                this.vernacularTitleField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ArticleDate")]
        public ArticleDateType[] ArticleDate {
            get {
                return this.articleDateField;
            }
            set {
                this.articleDateField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public ArticleTypePubModel PubModel {
            get {
                return this.pubModelField;
            }
            set {
                this.pubModelField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum ArticleTypePubModel {
        
        /// <remarks/>
        Print,
        
        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("Print-Electronic")]
        PrintElectronic,
        
        /// <remarks/>
        Electronic,
        
        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("Electronic-Print")]
        ElectronicPrint,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class DateRevisedType {
        
        private string yearField;
        
        private string monthField;
        
        private string dayField;
        
        /// <remarks/>
        public string Year {
            get {
                return this.yearField;
            }
            set {
                this.yearField = value;
            }
        }
        
        /// <remarks/>
        public string Month {
            get {
                return this.monthField;
            }
            set {
                this.monthField = value;
            }
        }
        
        /// <remarks/>
        public string Day {
            get {
                return this.dayField;
            }
            set {
                this.dayField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class DateCompletedType {
        
        private string yearField;
        
        private string monthField;
        
        private string dayField;
        
        /// <remarks/>
        public string Year {
            get {
                return this.yearField;
            }
            set {
                this.yearField = value;
            }
        }
        
        /// <remarks/>
        public string Month {
            get {
                return this.monthField;
            }
            set {
                this.monthField = value;
            }
        }
        
        /// <remarks/>
        public string Day {
            get {
                return this.dayField;
            }
            set {
                this.dayField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class DateCreatedType {
        
        private string yearField;
        
        private string monthField;
        
        private string dayField;
        
        /// <remarks/>
        public string Year {
            get {
                return this.yearField;
            }
            set {
                this.yearField = value;
            }
        }
        
        /// <remarks/>
        public string Month {
            get {
                return this.monthField;
            }
            set {
                this.monthField = value;
            }
        }
        
        /// <remarks/>
        public string Day {
            get {
                return this.dayField;
            }
            set {
                this.dayField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class MedlineCitationType {
        
        private string pMIDField;
        
        private DateCreatedType dateCreatedField;
        
        private DateCompletedType dateCompletedField;
        
        private DateRevisedType dateRevisedField;
        
        private ArticleType articleField;
        
        private MedlineJournalInfoType medlineJournalInfoField;
        
        private ChemicalType[] chemicalListField;
        
        private string[] citationSubsetField;
        
        private CommentsCorrectionsType[] commentsCorrectionsListField;
        
        private string[] geneSymbolListField;
        
        private MeshHeadingType[] meshHeadingListField;
        
        private string numberOfReferencesField;
        
        private PersonalNameSubjectType[] personalNameSubjectListField;
        
        private OtherIDType[] otherIDField;
        
        private OtherAbstractType[] otherAbstractField;
        
        private KeywordListType[] keywordListField;
        
        private string[] spaceFlightMissionField;
        
        private InvestigatorType[] investigatorListField;
        
        private GeneralNoteType[] generalNoteField;
        
        private MedlineCitationTypeOwner ownerField;
        
        private MedlineCitationTypeStatus statusField;
        
        public MedlineCitationType() {
            this.ownerField = MedlineCitationTypeOwner.NLM;
        }
        
        /// <remarks/>
        public string PMID {
            get {
                return this.pMIDField;
            }
            set {
                this.pMIDField = value;
            }
        }
        
        /// <remarks/>
        public DateCreatedType DateCreated {
            get {
                return this.dateCreatedField;
            }
            set {
                this.dateCreatedField = value;
            }
        }
        
        /// <remarks/>
        public DateCompletedType DateCompleted {
            get {
                return this.dateCompletedField;
            }
            set {
                this.dateCompletedField = value;
            }
        }
        
        /// <remarks/>
        public DateRevisedType DateRevised {
            get {
                return this.dateRevisedField;
            }
            set {
                this.dateRevisedField = value;
            }
        }
        
        /// <remarks/>
        public ArticleType Article {
            get {
                return this.articleField;
            }
            set {
                this.articleField = value;
            }
        }
        
        /// <remarks/>
        public MedlineJournalInfoType MedlineJournalInfo {
            get {
                return this.medlineJournalInfoField;
            }
            set {
                this.medlineJournalInfoField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Chemical", IsNullable=false)]
        public ChemicalType[] ChemicalList {
            get {
                return this.chemicalListField;
            }
            set {
                this.chemicalListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("CitationSubset")]
        public string[] CitationSubset {
            get {
                return this.citationSubsetField;
            }
            set {
                this.citationSubsetField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("CommentsCorrections", IsNullable=false)]
        public CommentsCorrectionsType[] CommentsCorrectionsList {
            get {
                return this.commentsCorrectionsListField;
            }
            set {
                this.commentsCorrectionsListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("GeneSymbol", IsNullable=false)]
        public string[] GeneSymbolList {
            get {
                return this.geneSymbolListField;
            }
            set {
                this.geneSymbolListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("MeshHeading", IsNullable=false)]
        public MeshHeadingType[] MeshHeadingList {
            get {
                return this.meshHeadingListField;
            }
            set {
                this.meshHeadingListField = value;
            }
        }
        
        /// <remarks/>
        public string NumberOfReferences {
            get {
                return this.numberOfReferencesField;
            }
            set {
                this.numberOfReferencesField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("PersonalNameSubject", IsNullable=false)]
        public PersonalNameSubjectType[] PersonalNameSubjectList {
            get {
                return this.personalNameSubjectListField;
            }
            set {
                this.personalNameSubjectListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("OtherID")]
        public OtherIDType[] OtherID {
            get {
                return this.otherIDField;
            }
            set {
                this.otherIDField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("OtherAbstract")]
        public OtherAbstractType[] OtherAbstract {
            get {
                return this.otherAbstractField;
            }
            set {
                this.otherAbstractField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("KeywordList")]
        public KeywordListType[] KeywordList {
            get {
                return this.keywordListField;
            }
            set {
                this.keywordListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SpaceFlightMission")]
        public string[] SpaceFlightMission {
            get {
                return this.spaceFlightMissionField;
            }
            set {
                this.spaceFlightMissionField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Investigator", IsNullable=false)]
        public InvestigatorType[] InvestigatorList {
            get {
                return this.investigatorListField;
            }
            set {
                this.investigatorListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("GeneralNote")]
        public GeneralNoteType[] GeneralNote {
            get {
                return this.generalNoteField;
            }
            set {
                this.generalNoteField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        [System.ComponentModel.DefaultValueAttribute(MedlineCitationTypeOwner.NLM)]
        public MedlineCitationTypeOwner Owner {
            get {
                return this.ownerField;
            }
            set {
                this.ownerField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public MedlineCitationTypeStatus Status {
            get {
                return this.statusField;
            }
            set {
                this.statusField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum MedlineCitationTypeOwner {
        
        /// <remarks/>
        NLM,
        
        /// <remarks/>
        NASA,
        
        /// <remarks/>
        PIP,
        
        /// <remarks/>
        KIE,
        
        /// <remarks/>
        HSR,
        
        /// <remarks/>
        HMD,
        
        /// <remarks/>
        NOTNLM,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public enum MedlineCitationTypeStatus {
        
        /// <remarks/>
        Completed,
        
        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("In-Process")]
        InProcess,
        
        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("PubMed-not-MEDLINE")]
        PubMednotMEDLINE,
        
        /// <remarks/>
        [System.Xml.Serialization.XmlEnumAttribute("In-Data-Review")]
        InDataReview,
        
        /// <remarks/>
        Publisher,
        
        /// <remarks/>
        MEDLINE,
        
        /// <remarks/>
        OLDMEDLINE,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class PubmedArticleType {
        
        private MedlineCitationType medlineCitationField;
        
        private PubmedDataType pubmedDataField;
        
        /// <remarks/>
        public MedlineCitationType MedlineCitation {
            get {
                return this.medlineCitationField;
            }
            set {
                this.medlineCitationField = value;
            }
        }
        
        /// <remarks/>
        public PubmedDataType PubmedData {
            get {
                return this.pubmedDataField;
            }
            set {
                this.pubmedDataField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_pubmed")]
    public partial class eFetchResult {
        
        private string eRRORField;
        
        private PubmedArticleType[] pubmedArticleSetField;
        
        private string[] idListField;
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("PubmedArticle", IsNullable=false)]
        public PubmedArticleType[] PubmedArticleSet {
            get {
                return this.pubmedArticleSetField;
            }
            set {
                this.pubmedArticleSetField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Id", IsNullable=false)]
        public string[] IdList {
            get {
                return this.idListField;
            }
            set {
                this.idListField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    public delegate void run_eFetchCompletedEventHandler(object sender, run_eFetchCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class run_eFetchCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal run_eFetchCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public eFetchResult Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((eFetchResult)(this.results[0]));
            }
        }
    }
}

#pragma warning restore 1591