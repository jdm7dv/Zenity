﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************

#pragma warning disable 1591

namespace ZentityDataImport.eUtils {
    using System;
    using System.Web.Services;
    using System.Diagnostics;
    using System.Web.Services.Protocols;
    using System.ComponentModel;
    using System.Xml.Serialization;
    
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Web.Services.WebServiceBindingAttribute(Name="eUtilsServiceSoap", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/")]
    public partial class eUtilsService : System.Web.Services.Protocols.SoapHttpClientProtocol {
        
        private System.Threading.SendOrPostCallback run_eGqueryOperationCompleted;
        
        private System.Threading.SendOrPostCallback run_eInfoOperationCompleted;
        
        private System.Threading.SendOrPostCallback run_eSearchOperationCompleted;
        
        private System.Threading.SendOrPostCallback run_eSummaryOperationCompleted;
        
        private System.Threading.SendOrPostCallback run_eLinkOperationCompleted;
        
        private System.Threading.SendOrPostCallback run_eSpellOperationCompleted;
        
        private System.Threading.SendOrPostCallback run_ePostOperationCompleted;
        
        private bool useDefaultCredentialsSetExplicitly;
        
        /// <remarks/>
        public eUtilsService() {
            this.Url = global::ZentityDataImport.Properties.Settings.Default.ZentityDataImport_eUtils_eUtilsService;
            if ((this.IsLocalFileSystemWebService(this.Url) == true)) {
                this.UseDefaultCredentials = true;
                this.useDefaultCredentialsSetExplicitly = false;
            }
            else {
                this.useDefaultCredentialsSetExplicitly = true;
            }
        }
        
        public new string Url {
            get {
                return base.Url;
            }
            set {
                if ((((this.IsLocalFileSystemWebService(base.Url) == true) 
                            && (this.useDefaultCredentialsSetExplicitly == false)) 
                            && (this.IsLocalFileSystemWebService(value) == false))) {
                    base.UseDefaultCredentials = false;
                }
                base.Url = value;
            }
        }
        
        public new bool UseDefaultCredentials {
            get {
                return base.UseDefaultCredentials;
            }
            set {
                base.UseDefaultCredentials = value;
                this.useDefaultCredentialsSetExplicitly = true;
            }
        }
        
        /// <remarks/>
        public event run_eGqueryCompletedEventHandler run_eGqueryCompleted;
        
        /// <remarks/>
        public event run_eInfoCompletedEventHandler run_eInfoCompleted;
        
        /// <remarks/>
        public event run_eSearchCompletedEventHandler run_eSearchCompleted;
        
        /// <remarks/>
        public event run_eSummaryCompletedEventHandler run_eSummaryCompleted;
        
        /// <remarks/>
        public event run_eLinkCompletedEventHandler run_eLinkCompleted;
        
        /// <remarks/>
        public event run_eSpellCompletedEventHandler run_eSpellCompleted;
        
        /// <remarks/>
        public event run_ePostCompletedEventHandler run_ePostCompleted;
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("egquery", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("Result", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/egquery")]
        public Result run_eGquery([System.Xml.Serialization.XmlElementAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/egquery")] eGqueryRequest eGqueryRequest) {
            object[] results = this.Invoke("run_eGquery", new object[] {
                        eGqueryRequest});
            return ((Result)(results[0]));
        }
        
        /// <remarks/>
        public void run_eGqueryAsync(eGqueryRequest eGqueryRequest) {
            this.run_eGqueryAsync(eGqueryRequest, null);
        }
        
        /// <remarks/>
        public void run_eGqueryAsync(eGqueryRequest eGqueryRequest, object userState) {
            if ((this.run_eGqueryOperationCompleted == null)) {
                this.run_eGqueryOperationCompleted = new System.Threading.SendOrPostCallback(this.Onrun_eGqueryOperationCompleted);
            }
            this.InvokeAsync("run_eGquery", new object[] {
                        eGqueryRequest}, this.run_eGqueryOperationCompleted, userState);
        }
        
        private void Onrun_eGqueryOperationCompleted(object arg) {
            if ((this.run_eGqueryCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.run_eGqueryCompleted(this, new run_eGqueryCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("einfo", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("eInfoResult", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/einfo")]
        public eInfoResult run_eInfo([System.Xml.Serialization.XmlElementAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/einfo")] eInfoRequest eInfoRequest) {
            object[] results = this.Invoke("run_eInfo", new object[] {
                        eInfoRequest});
            return ((eInfoResult)(results[0]));
        }
        
        /// <remarks/>
        public void run_eInfoAsync(eInfoRequest eInfoRequest) {
            this.run_eInfoAsync(eInfoRequest, null);
        }
        
        /// <remarks/>
        public void run_eInfoAsync(eInfoRequest eInfoRequest, object userState) {
            if ((this.run_eInfoOperationCompleted == null)) {
                this.run_eInfoOperationCompleted = new System.Threading.SendOrPostCallback(this.Onrun_eInfoOperationCompleted);
            }
            this.InvokeAsync("run_eInfo", new object[] {
                        eInfoRequest}, this.run_eInfoOperationCompleted, userState);
        }
        
        private void Onrun_eInfoOperationCompleted(object arg) {
            if ((this.run_eInfoCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.run_eInfoCompleted(this, new run_eInfoCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("esearch", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("eSearchResult", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esearch")]
        public eSearchResult run_eSearch([System.Xml.Serialization.XmlElementAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esearch")] eSearchRequest eSearchRequest) {
            object[] results = this.Invoke("run_eSearch", new object[] {
                        eSearchRequest});
            return ((eSearchResult)(results[0]));
        }
        
        /// <remarks/>
        public void run_eSearchAsync(eSearchRequest eSearchRequest) {
            this.run_eSearchAsync(eSearchRequest, null);
        }
        
        /// <remarks/>
        public void run_eSearchAsync(eSearchRequest eSearchRequest, object userState) {
            if ((this.run_eSearchOperationCompleted == null)) {
                this.run_eSearchOperationCompleted = new System.Threading.SendOrPostCallback(this.Onrun_eSearchOperationCompleted);
            }
            this.InvokeAsync("run_eSearch", new object[] {
                        eSearchRequest}, this.run_eSearchOperationCompleted, userState);
        }
        
        private void Onrun_eSearchOperationCompleted(object arg) {
            if ((this.run_eSearchCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.run_eSearchCompleted(this, new run_eSearchCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("esummary", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("eSummaryResult", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esummary")]
        public eSummaryResult run_eSummary([System.Xml.Serialization.XmlElementAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esummary")] eSummaryRequest eSummaryRequest) {
            object[] results = this.Invoke("run_eSummary", new object[] {
                        eSummaryRequest});
            return ((eSummaryResult)(results[0]));
        }
        
        /// <remarks/>
        public void run_eSummaryAsync(eSummaryRequest eSummaryRequest) {
            this.run_eSummaryAsync(eSummaryRequest, null);
        }
        
        /// <remarks/>
        public void run_eSummaryAsync(eSummaryRequest eSummaryRequest, object userState) {
            if ((this.run_eSummaryOperationCompleted == null)) {
                this.run_eSummaryOperationCompleted = new System.Threading.SendOrPostCallback(this.Onrun_eSummaryOperationCompleted);
            }
            this.InvokeAsync("run_eSummary", new object[] {
                        eSummaryRequest}, this.run_eSummaryOperationCompleted, userState);
        }
        
        private void Onrun_eSummaryOperationCompleted(object arg) {
            if ((this.run_eSummaryCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.run_eSummaryCompleted(this, new run_eSummaryCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("elink", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("eLinkResult", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
        public eLinkResult run_eLink([System.Xml.Serialization.XmlElementAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")] eLinkRequest eLinkRequest) {
            object[] results = this.Invoke("run_eLink", new object[] {
                        eLinkRequest});
            return ((eLinkResult)(results[0]));
        }
        
        /// <remarks/>
        public void run_eLinkAsync(eLinkRequest eLinkRequest) {
            this.run_eLinkAsync(eLinkRequest, null);
        }
        
        /// <remarks/>
        public void run_eLinkAsync(eLinkRequest eLinkRequest, object userState) {
            if ((this.run_eLinkOperationCompleted == null)) {
                this.run_eLinkOperationCompleted = new System.Threading.SendOrPostCallback(this.Onrun_eLinkOperationCompleted);
            }
            this.InvokeAsync("run_eLink", new object[] {
                        eLinkRequest}, this.run_eLinkOperationCompleted, userState);
        }
        
        private void Onrun_eLinkOperationCompleted(object arg) {
            if ((this.run_eLinkCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.run_eLinkCompleted(this, new run_eLinkCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("espell", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("eSpellResult", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/espell")]
        public eSpellResult run_eSpell([System.Xml.Serialization.XmlElementAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/espell")] eSpellRequest eSpellRequest) {
            object[] results = this.Invoke("run_eSpell", new object[] {
                        eSpellRequest});
            return ((eSpellResult)(results[0]));
        }
        
        /// <remarks/>
        public void run_eSpellAsync(eSpellRequest eSpellRequest) {
            this.run_eSpellAsync(eSpellRequest, null);
        }
        
        /// <remarks/>
        public void run_eSpellAsync(eSpellRequest eSpellRequest, object userState) {
            if ((this.run_eSpellOperationCompleted == null)) {
                this.run_eSpellOperationCompleted = new System.Threading.SendOrPostCallback(this.Onrun_eSpellOperationCompleted);
            }
            this.InvokeAsync("run_eSpell", new object[] {
                        eSpellRequest}, this.run_eSpellOperationCompleted, userState);
        }
        
        private void Onrun_eSpellOperationCompleted(object arg) {
            if ((this.run_eSpellCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.run_eSpellCompleted(this, new run_eSpellCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("epost", Use=System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle=System.Web.Services.Protocols.SoapParameterStyle.Bare)]
        [return: System.Xml.Serialization.XmlElementAttribute("ePostResult", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/epost")]
        public ePostResult run_ePost([System.Xml.Serialization.XmlElementAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/epost")] ePostRequest ePostRequest) {
            object[] results = this.Invoke("run_ePost", new object[] {
                        ePostRequest});
            return ((ePostResult)(results[0]));
        }
        
        /// <remarks/>
        public void run_ePostAsync(ePostRequest ePostRequest) {
            this.run_ePostAsync(ePostRequest, null);
        }
        
        /// <remarks/>
        public void run_ePostAsync(ePostRequest ePostRequest, object userState) {
            if ((this.run_ePostOperationCompleted == null)) {
                this.run_ePostOperationCompleted = new System.Threading.SendOrPostCallback(this.Onrun_ePostOperationCompleted);
            }
            this.InvokeAsync("run_ePost", new object[] {
                        ePostRequest}, this.run_ePostOperationCompleted, userState);
        }
        
        private void Onrun_ePostOperationCompleted(object arg) {
            if ((this.run_ePostCompleted != null)) {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.run_ePostCompleted(this, new run_ePostCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        /// <remarks/>
        public new void CancelAsync(object userState) {
            base.CancelAsync(userState);
        }
        
        private bool IsLocalFileSystemWebService(string url) {
            if (((url == null) 
                        || (url == string.Empty))) {
                return false;
            }
            System.Uri wsUri = new System.Uri(url);
            if (((wsUri.Port >= 1024) 
                        && (string.Compare(wsUri.Host, "localHost", System.StringComparison.OrdinalIgnoreCase) == 0))) {
                return true;
            }
            return false;
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/egquery")]
    public partial class eGqueryRequest {
        
        private string termField;
        
        private string toolField;
        
        private string emailField;
        
        /// <remarks/>
        public string term {
            get {
                return this.termField;
            }
            set {
                this.termField = value;
            }
        }
        
        /// <remarks/>
        public string tool {
            get {
                return this.toolField;
            }
            set {
                this.toolField = value;
            }
        }
        
        /// <remarks/>
        public string email {
            get {
                return this.emailField;
            }
            set {
                this.emailField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class LinkInfoType {
        
        private string dbToField;
        
        private string linkNameField;
        
        private string menuTagField;
        
        private string htmlTagField;
        
        private string urlField;
        
        private string priorityField;
        
        /// <remarks/>
        public string DbTo {
            get {
                return this.dbToField;
            }
            set {
                this.dbToField = value;
            }
        }
        
        /// <remarks/>
        public string LinkName {
            get {
                return this.linkNameField;
            }
            set {
                this.linkNameField = value;
            }
        }
        
        /// <remarks/>
        public string MenuTag {
            get {
                return this.menuTagField;
            }
            set {
                this.menuTagField = value;
            }
        }
        
        /// <remarks/>
        public string HtmlTag {
            get {
                return this.htmlTagField;
            }
            set {
                this.htmlTagField = value;
            }
        }
        
        /// <remarks/>
        public string Url {
            get {
                return this.urlField;
            }
            set {
                this.urlField = value;
            }
        }
        
        /// <remarks/>
        public string Priority {
            get {
                return this.priorityField;
            }
            set {
                this.priorityField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class IdLinkSetType {
        
        private IdType idField;
        
        private LinkInfoType[] linkInfoField;
        
        /// <remarks/>
        public IdType Id {
            get {
                return this.idField;
            }
            set {
                this.idField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("LinkInfo")]
        public LinkInfoType[] LinkInfo {
            get {
                return this.linkInfoField;
            }
            set {
                this.linkInfoField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class IdType {
        
        private IdTypeHasLinkOut hasLinkOutField;
        
        private bool hasLinkOutFieldSpecified;
        
        private IdTypeHasNeighbor hasNeighborField;
        
        private bool hasNeighborFieldSpecified;
        
        private string valueField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public IdTypeHasLinkOut HasLinkOut {
            get {
                return this.hasLinkOutField;
            }
            set {
                this.hasLinkOutField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool HasLinkOutSpecified {
            get {
                return this.hasLinkOutFieldSpecified;
            }
            set {
                this.hasLinkOutFieldSpecified = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public IdTypeHasNeighbor HasNeighbor {
            get {
                return this.hasNeighborField;
            }
            set {
                this.hasNeighborField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool HasNeighborSpecified {
            get {
                return this.hasNeighborFieldSpecified;
            }
            set {
                this.hasNeighborFieldSpecified = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value {
            get {
                return this.valueField;
            }
            set {
                this.valueField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public enum IdTypeHasLinkOut {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public enum IdTypeHasNeighbor {
        
        /// <remarks/>
        Y,
        
        /// <remarks/>
        N,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class IdCheckListType {
        
        private object[] itemsField;
        
        private string eRRORField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Id", typeof(IdType))]
        [System.Xml.Serialization.XmlElementAttribute("IdLinkSet", typeof(IdLinkSetType))]
        public object[] Items {
            get {
                return this.itemsField;
            }
            set {
                this.itemsField = value;
            }
        }
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class ProviderType {
        
        private string nameField;
        
        private string nameAbbrField;
        
        private IdType idField;
        
        private string urlField;
        
        private string iconUrlField;
        
        /// <remarks/>
        public string Name {
            get {
                return this.nameField;
            }
            set {
                this.nameField = value;
            }
        }
        
        /// <remarks/>
        public string NameAbbr {
            get {
                return this.nameAbbrField;
            }
            set {
                this.nameAbbrField = value;
            }
        }
        
        /// <remarks/>
        public IdType Id {
            get {
                return this.idField;
            }
            set {
                this.idField = value;
            }
        }
        
        /// <remarks/>
        public string Url {
            get {
                return this.urlField;
            }
            set {
                this.urlField = value;
            }
        }
        
        /// <remarks/>
        public string IconUrl {
            get {
                return this.iconUrlField;
            }
            set {
                this.iconUrlField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class ObjUrlType {
        
        private string urlField;
        
        private string iconUrlField;
        
        private string linkNameField;
        
        private string[] subjectTypeField;
        
        private string[] categoryField;
        
        private string[] attributeField;
        
        private ProviderType providerField;
        
        /// <remarks/>
        public string Url {
            get {
                return this.urlField;
            }
            set {
                this.urlField = value;
            }
        }
        
        /// <remarks/>
        public string IconUrl {
            get {
                return this.iconUrlField;
            }
            set {
                this.iconUrlField = value;
            }
        }
        
        /// <remarks/>
        public string LinkName {
            get {
                return this.linkNameField;
            }
            set {
                this.linkNameField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("SubjectType")]
        public string[] SubjectType {
            get {
                return this.subjectTypeField;
            }
            set {
                this.subjectTypeField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Category")]
        public string[] Category {
            get {
                return this.categoryField;
            }
            set {
                this.categoryField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Attribute")]
        public string[] Attribute {
            get {
                return this.attributeField;
            }
            set {
                this.attributeField = value;
            }
        }
        
        /// <remarks/>
        public ProviderType Provider {
            get {
                return this.providerField;
            }
            set {
                this.providerField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class IdUrlSetType {
        
        private IdType idField;
        
        private object[] itemsField;
        
        /// <remarks/>
        public IdType Id {
            get {
                return this.idField;
            }
            set {
                this.idField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Info", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("ObjUrl", typeof(ObjUrlType))]
        public object[] Items {
            get {
                return this.itemsField;
            }
            set {
                this.itemsField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class IdUrlListType {
        
        private IdUrlSetType[] idUrlSetField;
        
        private string eRRORField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("IdUrlSet")]
        public IdUrlSetType[] IdUrlSet {
            get {
                return this.idUrlSetField;
            }
            set {
                this.idUrlSetField = value;
            }
        }
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class LinkSetDbHistoryType {
        
        private string dbToField;
        
        private string linkNameField;
        
        private string queryKeyField;
        
        private string infoField;
        
        private string eRRORField;
        
        /// <remarks/>
        public string DbTo {
            get {
                return this.dbToField;
            }
            set {
                this.dbToField = value;
            }
        }
        
        /// <remarks/>
        public string LinkName {
            get {
                return this.linkNameField;
            }
            set {
                this.linkNameField = value;
            }
        }
        
        /// <remarks/>
        public string QueryKey {
            get {
                return this.queryKeyField;
            }
            set {
                this.queryKeyField = value;
            }
        }
        
        /// <remarks/>
        public string Info {
            get {
                return this.infoField;
            }
            set {
                this.infoField = value;
            }
        }
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(TypeName="LinkType", Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class LinkType1 {
        
        private IdType idField;
        
        private string scoreField;
        
        /// <remarks/>
        public IdType Id {
            get {
                return this.idField;
            }
            set {
                this.idField = value;
            }
        }
        
        /// <remarks/>
        public string Score {
            get {
                return this.scoreField;
            }
            set {
                this.scoreField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class LinkSetDbType {
        
        private string dbToField;
        
        private string linkNameField;
        
        private LinkType1[] linkField;
        
        private string infoField;
        
        private string eRRORField;
        
        /// <remarks/>
        public string DbTo {
            get {
                return this.dbToField;
            }
            set {
                this.dbToField = value;
            }
        }
        
        /// <remarks/>
        public string LinkName {
            get {
                return this.linkNameField;
            }
            set {
                this.linkNameField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Link")]
        public LinkType1[] Link {
            get {
                return this.linkField;
            }
            set {
                this.linkField = value;
            }
        }
        
        /// <remarks/>
        public string Info {
            get {
                return this.infoField;
            }
            set {
                this.infoField = value;
            }
        }
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class LinkSetType {
        
        private string dbFromField;
        
        private IdType[] idListField;
        
        private LinkSetDbType[] linkSetDbField;
        
        private LinkSetDbHistoryType[] linkSetDbHistoryField;
        
        private string webEnvField;
        
        private IdUrlListType idUrlListField;
        
        private IdCheckListType idCheckListField;
        
        private string eRRORField;
        
        /// <remarks/>
        public string DbFrom {
            get {
                return this.dbFromField;
            }
            set {
                this.dbFromField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Id", IsNullable=false)]
        public IdType[] IdList {
            get {
                return this.idListField;
            }
            set {
                this.idListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("LinkSetDb")]
        public LinkSetDbType[] LinkSetDb {
            get {
                return this.linkSetDbField;
            }
            set {
                this.linkSetDbField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("LinkSetDbHistory")]
        public LinkSetDbHistoryType[] LinkSetDbHistory {
            get {
                return this.linkSetDbHistoryField;
            }
            set {
                this.linkSetDbHistoryField = value;
            }
        }
        
        /// <remarks/>
        public string WebEnv {
            get {
                return this.webEnvField;
            }
            set {
                this.webEnvField = value;
            }
        }
        
        /// <remarks/>
        public IdUrlListType IdUrlList {
            get {
                return this.idUrlListField;
            }
            set {
                this.idUrlListField = value;
            }
        }
        
        /// <remarks/>
        public IdCheckListType IdCheckList {
            get {
                return this.idCheckListField;
            }
            set {
                this.idCheckListField = value;
            }
        }
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esummary")]
    public partial class ItemType {
        
        private ItemType[] itemField;
        
        private string itemContentField;
        
        private string nameField;
        
        private ItemTypeType typeField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Item")]
        public ItemType[] Item {
            get {
                return this.itemField;
            }
            set {
                this.itemField = value;
            }
        }
        
        /// <remarks/>
        public string ItemContent {
            get {
                return this.itemContentField;
            }
            set {
                this.itemContentField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string Name {
            get {
                return this.nameField;
            }
            set {
                this.nameField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public ItemTypeType Type {
            get {
                return this.typeField;
            }
            set {
                this.typeField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esummary")]
    public enum ItemTypeType {
        
        /// <remarks/>
        Integer,
        
        /// <remarks/>
        Date,
        
        /// <remarks/>
        String,
        
        /// <remarks/>
        Structure,
        
        /// <remarks/>
        List,
        
        /// <remarks/>
        Flags,
        
        /// <remarks/>
        Qualifier,
        
        /// <remarks/>
        Enumerator,
        
        /// <remarks/>
        Unknown,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esummary")]
    public partial class DocSumType {
        
        private string idField;
        
        private ItemType[] itemField;
        
        /// <remarks/>
        public string Id {
            get {
                return this.idField;
            }
            set {
                this.idField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Item")]
        public ItemType[] Item {
            get {
                return this.itemField;
            }
            set {
                this.itemField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esearch")]
    public partial class WarningListType {
        
        private string[] phraseIgnoredField;
        
        private string[] quotedPhraseNotFoundField;
        
        private string[] outputMessageField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("PhraseIgnored")]
        public string[] PhraseIgnored {
            get {
                return this.phraseIgnoredField;
            }
            set {
                this.phraseIgnoredField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("QuotedPhraseNotFound")]
        public string[] QuotedPhraseNotFound {
            get {
                return this.quotedPhraseNotFoundField;
            }
            set {
                this.quotedPhraseNotFoundField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("OutputMessage")]
        public string[] OutputMessage {
            get {
                return this.outputMessageField;
            }
            set {
                this.outputMessageField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esearch")]
    public partial class ErrorListType {
        
        private string[] phraseNotFoundField;
        
        private string[] fieldNotFoundField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("PhraseNotFound")]
        public string[] PhraseNotFound {
            get {
                return this.phraseNotFoundField;
            }
            set {
                this.phraseNotFoundField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("FieldNotFound")]
        public string[] FieldNotFound {
            get {
                return this.fieldNotFoundField;
            }
            set {
                this.fieldNotFoundField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esearch")]
    public partial class TermSetType {
        
        private string termField;
        
        private string fieldField;
        
        private string countField;
        
        private string explodeField;
        
        /// <remarks/>
        public string Term {
            get {
                return this.termField;
            }
            set {
                this.termField = value;
            }
        }
        
        /// <remarks/>
        public string Field {
            get {
                return this.fieldField;
            }
            set {
                this.fieldField = value;
            }
        }
        
        /// <remarks/>
        public string Count {
            get {
                return this.countField;
            }
            set {
                this.countField = value;
            }
        }
        
        /// <remarks/>
        public string Explode {
            get {
                return this.explodeField;
            }
            set {
                this.explodeField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esearch")]
    public partial class TranslationType {
        
        private string fromField;
        
        private string toField;
        
        /// <remarks/>
        public string From {
            get {
                return this.fromField;
            }
            set {
                this.fromField = value;
            }
        }
        
        /// <remarks/>
        public string To {
            get {
                return this.toField;
            }
            set {
                this.toField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/einfo")]
    public partial class LinkType {
        
        private string nameField;
        
        private string menuField;
        
        private string descriptionField;
        
        private string dbToField;
        
        /// <remarks/>
        public string Name {
            get {
                return this.nameField;
            }
            set {
                this.nameField = value;
            }
        }
        
        /// <remarks/>
        public string Menu {
            get {
                return this.menuField;
            }
            set {
                this.menuField = value;
            }
        }
        
        /// <remarks/>
        public string Description {
            get {
                return this.descriptionField;
            }
            set {
                this.descriptionField = value;
            }
        }
        
        /// <remarks/>
        public string DbTo {
            get {
                return this.dbToField;
            }
            set {
                this.dbToField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/einfo")]
    public partial class FieldType {
        
        private string nameField;
        
        private string fullNameField;
        
        private string descriptionField;
        
        private string termCountField;
        
        private string isDateField;
        
        private string isNumericalField;
        
        private string singleTokenField;
        
        private string hierarchyField;
        
        private string isHiddenField;
        
        /// <remarks/>
        public string Name {
            get {
                return this.nameField;
            }
            set {
                this.nameField = value;
            }
        }
        
        /// <remarks/>
        public string FullName {
            get {
                return this.fullNameField;
            }
            set {
                this.fullNameField = value;
            }
        }
        
        /// <remarks/>
        public string Description {
            get {
                return this.descriptionField;
            }
            set {
                this.descriptionField = value;
            }
        }
        
        /// <remarks/>
        public string TermCount {
            get {
                return this.termCountField;
            }
            set {
                this.termCountField = value;
            }
        }
        
        /// <remarks/>
        public string IsDate {
            get {
                return this.isDateField;
            }
            set {
                this.isDateField = value;
            }
        }
        
        /// <remarks/>
        public string IsNumerical {
            get {
                return this.isNumericalField;
            }
            set {
                this.isNumericalField = value;
            }
        }
        
        /// <remarks/>
        public string SingleToken {
            get {
                return this.singleTokenField;
            }
            set {
                this.singleTokenField = value;
            }
        }
        
        /// <remarks/>
        public string Hierarchy {
            get {
                return this.hierarchyField;
            }
            set {
                this.hierarchyField = value;
            }
        }
        
        /// <remarks/>
        public string IsHidden {
            get {
                return this.isHiddenField;
            }
            set {
                this.isHiddenField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/einfo")]
    public partial class DbInfoType {
        
        private string dbNameField;
        
        private string menuNameField;
        
        private string descriptionField;
        
        private string countField;
        
        private string lastUpdateField;
        
        private FieldType[] fieldListField;
        
        private LinkType[] linkListField;
        
        /// <remarks/>
        public string DbName {
            get {
                return this.dbNameField;
            }
            set {
                this.dbNameField = value;
            }
        }
        
        /// <remarks/>
        public string MenuName {
            get {
                return this.menuNameField;
            }
            set {
                this.menuNameField = value;
            }
        }
        
        /// <remarks/>
        public string Description {
            get {
                return this.descriptionField;
            }
            set {
                this.descriptionField = value;
            }
        }
        
        /// <remarks/>
        public string Count {
            get {
                return this.countField;
            }
            set {
                this.countField = value;
            }
        }
        
        /// <remarks/>
        public string LastUpdate {
            get {
                return this.lastUpdateField;
            }
            set {
                this.lastUpdateField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Field", IsNullable=false)]
        public FieldType[] FieldList {
            get {
                return this.fieldListField;
            }
            set {
                this.fieldListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Link", IsNullable=false)]
        public LinkType[] LinkList {
            get {
                return this.linkListField;
            }
            set {
                this.linkListField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/einfo")]
    public partial class DbListType {
        
        private string[] itemsField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("DbName")]
        public string[] Items {
            get {
                return this.itemsField;
            }
            set {
                this.itemsField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/egquery")]
    public partial class ResultItemType {
        
        private string dbNameField;
        
        private string menuNameField;
        
        private string countField;
        
        private string statusField;
        
        /// <remarks/>
        public string DbName {
            get {
                return this.dbNameField;
            }
            set {
                this.dbNameField = value;
            }
        }
        
        /// <remarks/>
        public string MenuName {
            get {
                return this.menuNameField;
            }
            set {
                this.menuNameField = value;
            }
        }
        
        /// <remarks/>
        public string Count {
            get {
                return this.countField;
            }
            set {
                this.countField = value;
            }
        }
        
        /// <remarks/>
        public string Status {
            get {
                return this.statusField;
            }
            set {
                this.statusField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/egquery")]
    public partial class eGQueryResultType {
        
        private string eRRORField;
        
        private ResultItemType[] resultItemField;
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ResultItem")]
        public ResultItemType[] ResultItem {
            get {
                return this.resultItemField;
            }
            set {
                this.resultItemField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/egquery")]
    public partial class Result {
        
        private string termField;
        
        private eGQueryResultType eGQueryResultField;
        
        /// <remarks/>
        public string Term {
            get {
                return this.termField;
            }
            set {
                this.termField = value;
            }
        }
        
        /// <remarks/>
        public eGQueryResultType eGQueryResult {
            get {
                return this.eGQueryResultField;
            }
            set {
                this.eGQueryResultField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/einfo")]
    public partial class eInfoRequest {
        
        private string dbField;
        
        private string toolField;
        
        private string emailField;
        
        /// <remarks/>
        public string db {
            get {
                return this.dbField;
            }
            set {
                this.dbField = value;
            }
        }
        
        /// <remarks/>
        public string tool {
            get {
                return this.toolField;
            }
            set {
                this.toolField = value;
            }
        }
        
        /// <remarks/>
        public string email {
            get {
                return this.emailField;
            }
            set {
                this.emailField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/einfo")]
    public partial class eInfoResult {
        
        private string eRRORField;
        
        private DbListType dbListField;
        
        private DbInfoType dbInfoField;
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
        
        /// <remarks/>
        public DbListType DbList {
            get {
                return this.dbListField;
            }
            set {
                this.dbListField = value;
            }
        }
        
        /// <remarks/>
        public DbInfoType DbInfo {
            get {
                return this.dbInfoField;
            }
            set {
                this.dbInfoField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esearch")]
    public partial class eSearchRequest {
        
        private string dbField;
        
        private string termField;
        
        private string webEnvField;
        
        private string queryKeyField;
        
        private string usehistoryField;
        
        private string toolField;
        
        private string emailField;
        
        private string fieldField;
        
        private string reldateField;
        
        private string mindateField;
        
        private string maxdateField;
        
        private string datetypeField;
        
        private string retStartField;
        
        private string retMaxField;
        
        private string rettypeField;
        
        private string sortField;
        
        /// <remarks/>
        public string db {
            get {
                return this.dbField;
            }
            set {
                this.dbField = value;
            }
        }
        
        /// <remarks/>
        public string term {
            get {
                return this.termField;
            }
            set {
                this.termField = value;
            }
        }
        
        /// <remarks/>
        public string WebEnv {
            get {
                return this.webEnvField;
            }
            set {
                this.webEnvField = value;
            }
        }
        
        /// <remarks/>
        public string QueryKey {
            get {
                return this.queryKeyField;
            }
            set {
                this.queryKeyField = value;
            }
        }
        
        /// <remarks/>
        public string usehistory {
            get {
                return this.usehistoryField;
            }
            set {
                this.usehistoryField = value;
            }
        }
        
        /// <remarks/>
        public string tool {
            get {
                return this.toolField;
            }
            set {
                this.toolField = value;
            }
        }
        
        /// <remarks/>
        public string email {
            get {
                return this.emailField;
            }
            set {
                this.emailField = value;
            }
        }
        
        /// <remarks/>
        public string field {
            get {
                return this.fieldField;
            }
            set {
                this.fieldField = value;
            }
        }
        
        /// <remarks/>
        public string reldate {
            get {
                return this.reldateField;
            }
            set {
                this.reldateField = value;
            }
        }
        
        /// <remarks/>
        public string mindate {
            get {
                return this.mindateField;
            }
            set {
                this.mindateField = value;
            }
        }
        
        /// <remarks/>
        public string maxdate {
            get {
                return this.maxdateField;
            }
            set {
                this.maxdateField = value;
            }
        }
        
        /// <remarks/>
        public string datetype {
            get {
                return this.datetypeField;
            }
            set {
                this.datetypeField = value;
            }
        }
        
        /// <remarks/>
        public string RetStart {
            get {
                return this.retStartField;
            }
            set {
                this.retStartField = value;
            }
        }
        
        /// <remarks/>
        public string RetMax {
            get {
                return this.retMaxField;
            }
            set {
                this.retMaxField = value;
            }
        }
        
        /// <remarks/>
        public string rettype {
            get {
                return this.rettypeField;
            }
            set {
                this.rettypeField = value;
            }
        }
        
        /// <remarks/>
        public string sort {
            get {
                return this.sortField;
            }
            set {
                this.sortField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esearch")]
    public partial class eSearchResult {
        
        private string eRRORField;
        
        private string countField;
        
        private string retMaxField;
        
        private string retStartField;
        
        private string queryKeyField;
        
        private string webEnvField;
        
        private string[] idListField;
        
        private TranslationType[] translationSetField;
        
        private object[] translationStackField;
        
        private string queryTranslationField;
        
        private ErrorListType errorListField;
        
        private WarningListType warningListField;
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
        
        /// <remarks/>
        public string Count {
            get {
                return this.countField;
            }
            set {
                this.countField = value;
            }
        }
        
        /// <remarks/>
        public string RetMax {
            get {
                return this.retMaxField;
            }
            set {
                this.retMaxField = value;
            }
        }
        
        /// <remarks/>
        public string RetStart {
            get {
                return this.retStartField;
            }
            set {
                this.retStartField = value;
            }
        }
        
        /// <remarks/>
        public string QueryKey {
            get {
                return this.queryKeyField;
            }
            set {
                this.queryKeyField = value;
            }
        }
        
        /// <remarks/>
        public string WebEnv {
            get {
                return this.webEnvField;
            }
            set {
                this.webEnvField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Id", IsNullable=false)]
        public string[] IdList {
            get {
                return this.idListField;
            }
            set {
                this.idListField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Translation", IsNullable=false)]
        public TranslationType[] TranslationSet {
            get {
                return this.translationSetField;
            }
            set {
                this.translationSetField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("OP", typeof(string), IsNullable=false)]
        [System.Xml.Serialization.XmlArrayItemAttribute("TermSet", typeof(TermSetType), IsNullable=false)]
        public object[] TranslationStack {
            get {
                return this.translationStackField;
            }
            set {
                this.translationStackField = value;
            }
        }
        
        /// <remarks/>
        public string QueryTranslation {
            get {
                return this.queryTranslationField;
            }
            set {
                this.queryTranslationField = value;
            }
        }
        
        /// <remarks/>
        public ErrorListType ErrorList {
            get {
                return this.errorListField;
            }
            set {
                this.errorListField = value;
            }
        }
        
        /// <remarks/>
        public WarningListType WarningList {
            get {
                return this.warningListField;
            }
            set {
                this.warningListField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esummary")]
    public partial class eSummaryRequest {
        
        private string dbField;
        
        private string idField;
        
        private string webEnvField;
        
        private string query_keyField;
        
        private string retstartField;
        
        private string retmaxField;
        
        private string toolField;
        
        private string emailField;
        
        /// <remarks/>
        public string db {
            get {
                return this.dbField;
            }
            set {
                this.dbField = value;
            }
        }
        
        /// <remarks/>
        public string id {
            get {
                return this.idField;
            }
            set {
                this.idField = value;
            }
        }
        
        /// <remarks/>
        public string WebEnv {
            get {
                return this.webEnvField;
            }
            set {
                this.webEnvField = value;
            }
        }
        
        /// <remarks/>
        public string query_key {
            get {
                return this.query_keyField;
            }
            set {
                this.query_keyField = value;
            }
        }
        
        /// <remarks/>
        public string retstart {
            get {
                return this.retstartField;
            }
            set {
                this.retstartField = value;
            }
        }
        
        /// <remarks/>
        public string retmax {
            get {
                return this.retmaxField;
            }
            set {
                this.retmaxField = value;
            }
        }
        
        /// <remarks/>
        public string tool {
            get {
                return this.toolField;
            }
            set {
                this.toolField = value;
            }
        }
        
        /// <remarks/>
        public string email {
            get {
                return this.emailField;
            }
            set {
                this.emailField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/esummary")]
    public partial class eSummaryResult {
        
        private string eRRORField;
        
        private DocSumType[] docSumField;
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("DocSum")]
        public DocSumType[] DocSum {
            get {
                return this.docSumField;
            }
            set {
                this.docSumField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class eLinkRequest {
        
        private string dbField;
        
        private string[] idField;
        
        private string reldateField;
        
        private string mindateField;
        
        private string maxdateField;
        
        private string datetypeField;
        
        private string termField;
        
        private string dbfromField;
        
        private string linknameField;
        
        private string webEnvField;
        
        private string query_keyField;
        
        private string cmdField;
        
        private string toolField;
        
        private string emailField;
        
        /// <remarks/>
        public string db {
            get {
                return this.dbField;
            }
            set {
                this.dbField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("id")]
        public string[] id {
            get {
                return this.idField;
            }
            set {
                this.idField = value;
            }
        }
        
        /// <remarks/>
        public string reldate {
            get {
                return this.reldateField;
            }
            set {
                this.reldateField = value;
            }
        }
        
        /// <remarks/>
        public string mindate {
            get {
                return this.mindateField;
            }
            set {
                this.mindateField = value;
            }
        }
        
        /// <remarks/>
        public string maxdate {
            get {
                return this.maxdateField;
            }
            set {
                this.maxdateField = value;
            }
        }
        
        /// <remarks/>
        public string datetype {
            get {
                return this.datetypeField;
            }
            set {
                this.datetypeField = value;
            }
        }
        
        /// <remarks/>
        public string term {
            get {
                return this.termField;
            }
            set {
                this.termField = value;
            }
        }
        
        /// <remarks/>
        public string dbfrom {
            get {
                return this.dbfromField;
            }
            set {
                this.dbfromField = value;
            }
        }
        
        /// <remarks/>
        public string linkname {
            get {
                return this.linknameField;
            }
            set {
                this.linknameField = value;
            }
        }
        
        /// <remarks/>
        public string WebEnv {
            get {
                return this.webEnvField;
            }
            set {
                this.webEnvField = value;
            }
        }
        
        /// <remarks/>
        public string query_key {
            get {
                return this.query_keyField;
            }
            set {
                this.query_keyField = value;
            }
        }
        
        /// <remarks/>
        public string cmd {
            get {
                return this.cmdField;
            }
            set {
                this.cmdField = value;
            }
        }
        
        /// <remarks/>
        public string tool {
            get {
                return this.toolField;
            }
            set {
                this.toolField = value;
            }
        }
        
        /// <remarks/>
        public string email {
            get {
                return this.emailField;
            }
            set {
                this.emailField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/elink")]
    public partial class eLinkResult {
        
        private LinkSetType[] linkSetField;
        
        private string eRRORField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("LinkSet")]
        public LinkSetType[] LinkSet {
            get {
                return this.linkSetField;
            }
            set {
                this.linkSetField = value;
            }
        }
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/espell")]
    public partial class eSpellRequest {
        
        private string dbField;
        
        private string termField;
        
        private string toolField;
        
        private string emailField;
        
        /// <remarks/>
        public string db {
            get {
                return this.dbField;
            }
            set {
                this.dbField = value;
            }
        }
        
        /// <remarks/>
        public string term {
            get {
                return this.termField;
            }
            set {
                this.termField = value;
            }
        }
        
        /// <remarks/>
        public string tool {
            get {
                return this.toolField;
            }
            set {
                this.toolField = value;
            }
        }
        
        /// <remarks/>
        public string email {
            get {
                return this.emailField;
            }
            set {
                this.emailField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/espell")]
    public partial class eSpellResult {
        
        private string databaseField;
        
        private string queryField;
        
        private string correctedQueryField;
        
        private SpelledQuery spelledQueryField;
        
        private string eRRORField;
        
        /// <remarks/>
        public string Database {
            get {
                return this.databaseField;
            }
            set {
                this.databaseField = value;
            }
        }
        
        /// <remarks/>
        public string Query {
            get {
                return this.queryField;
            }
            set {
                this.queryField = value;
            }
        }
        
        /// <remarks/>
        public string CorrectedQuery {
            get {
                return this.correctedQueryField;
            }
            set {
                this.correctedQueryField = value;
            }
        }
        
        /// <remarks/>
        public SpelledQuery SpelledQuery {
            get {
                return this.spelledQueryField;
            }
            set {
                this.spelledQueryField = value;
            }
        }
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/espell")]
    public partial class SpelledQuery {
        
        private string[] itemsField;
        
        private ItemsChoiceType[] itemsElementNameField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Original", typeof(string))]
        [System.Xml.Serialization.XmlElementAttribute("Replaced", typeof(string))]
        [System.Xml.Serialization.XmlChoiceIdentifierAttribute("ItemsElementName")]
        public string[] Items {
            get {
                return this.itemsField;
            }
            set {
                this.itemsField = value;
            }
        }
        
        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("ItemsElementName")]
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public ItemsChoiceType[] ItemsElementName {
            get {
                return this.itemsElementNameField;
            }
            set {
                this.itemsElementNameField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/espell", IncludeInSchema=false)]
    public enum ItemsChoiceType {
        
        /// <remarks/>
        Original,
        
        /// <remarks/>
        Replaced,
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/epost")]
    public partial class ePostRequest {
        
        private string dbField;
        
        private string idField;
        
        private string webEnvField;
        
        private string toolField;
        
        private string emailField;
        
        /// <remarks/>
        public string db {
            get {
                return this.dbField;
            }
            set {
                this.dbField = value;
            }
        }
        
        /// <remarks/>
        public string id {
            get {
                return this.idField;
            }
            set {
                this.idField = value;
            }
        }
        
        /// <remarks/>
        public string WebEnv {
            get {
                return this.webEnvField;
            }
            set {
                this.webEnvField = value;
            }
        }
        
        /// <remarks/>
        public string tool {
            get {
                return this.toolField;
            }
            set {
                this.toolField = value;
            }
        }
        
        /// <remarks/>
        public string email {
            get {
                return this.emailField;
            }
            set {
                this.emailField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "4.0.30128.1")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType=true, Namespace="http://www.ncbi.nlm.nih.gov/soap/eutils/epost")]
    public partial class ePostResult {
        
        private string[] invalidIdListField;
        
        private string queryKeyField;
        
        private string webEnvField;
        
        private string eRRORField;
        
        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Id", IsNullable=false)]
        public string[] InvalidIdList {
            get {
                return this.invalidIdListField;
            }
            set {
                this.invalidIdListField = value;
            }
        }
        
        /// <remarks/>
        public string QueryKey {
            get {
                return this.queryKeyField;
            }
            set {
                this.queryKeyField = value;
            }
        }
        
        /// <remarks/>
        public string WebEnv {
            get {
                return this.webEnvField;
            }
            set {
                this.webEnvField = value;
            }
        }
        
        /// <remarks/>
        public string ERROR {
            get {
                return this.eRRORField;
            }
            set {
                this.eRRORField = value;
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    public delegate void run_eGqueryCompletedEventHandler(object sender, run_eGqueryCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class run_eGqueryCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal run_eGqueryCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public Result Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((Result)(this.results[0]));
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    public delegate void run_eInfoCompletedEventHandler(object sender, run_eInfoCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class run_eInfoCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal run_eInfoCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public eInfoResult Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((eInfoResult)(this.results[0]));
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    public delegate void run_eSearchCompletedEventHandler(object sender, run_eSearchCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class run_eSearchCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal run_eSearchCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public eSearchResult Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((eSearchResult)(this.results[0]));
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    public delegate void run_eSummaryCompletedEventHandler(object sender, run_eSummaryCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class run_eSummaryCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal run_eSummaryCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public eSummaryResult Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((eSummaryResult)(this.results[0]));
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    public delegate void run_eLinkCompletedEventHandler(object sender, run_eLinkCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class run_eLinkCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal run_eLinkCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public eLinkResult Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((eLinkResult)(this.results[0]));
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    public delegate void run_eSpellCompletedEventHandler(object sender, run_eSpellCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class run_eSpellCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal run_eSpellCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public eSpellResult Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((eSpellResult)(this.results[0]));
            }
        }
    }
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    public delegate void run_ePostCompletedEventHandler(object sender, run_ePostCompletedEventArgs e);
    
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Web.Services", "4.0.30128.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class run_ePostCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs {
        
        private object[] results;
        
        internal run_ePostCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) : 
                base(exception, cancelled, userState) {
            this.results = results;
        }
        
        /// <remarks/>
        public ePostResult Result {
            get {
                this.RaiseExceptionIfNecessary();
                return ((ePostResult)(this.results[0]));
            }
        }
    }
}

#pragma warning restore 1591