﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace ZentityDataImport
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Windows.Forms;
    using Zentity.ScholarlyWorks;
    using Zentity.Core;
    
    using ZentityDataImport.Control;
    using ZentityDataImport.Repository;

    /// <summary>
    /// Base Windows Form for the Data Import Application
    /// </summary>
    public partial class BaseForm : Form
    {
        /// <summary>
        /// Holds the reference to the input control
        /// </summary>
        private BaseInputControl inputControl;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseForm"/> class.
        /// </summary>
        public BaseForm()
        {
            this.InitializeComponent();
            this.InitializeControls();
            this.ComboRepository.SelectedIndex = 0;
        }

        /// <summary>
        /// Initializes the controls.
        /// </summary>
        private void InitializeControls()
        {
            IEnumerable<Type> assemblyTypes = Assembly.GetExecutingAssembly().GetTypes();
            
            // Self Registration of Factory Classes
            foreach (Type oneType in assemblyTypes)
            {
                if (oneType.BaseType != null && oneType.IsSubclassOf(typeof(BaseFactory)))
                {
                    var registerMethodInfo = oneType.GetMethod("Register", BindingFlags.Static | BindingFlags.Public);
                    var repositoryType = oneType.GetProperty(typeof(RepositoryType).Name, BindingFlags.Static | BindingFlags.Public);
                    
                    if (registerMethodInfo != null)
                    {
                        registerMethodInfo.Invoke(null, null);
                    }

                    if (repositoryType != null)
                    {
                        this.ComboRepository.Items.Add(repositoryType.GetValue(null, null));
                    }
                }
            }

            this.ComboRepository.SelectedIndexChanged += new EventHandler(this.ComboRepository_SelectedIndexChanged);
            this.DataGridRecords.AutoGenerateColumns = false;
        }

        /// <summary>
        /// Handles the Click event of the ButtonFetchData control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ButtonFetchData_Click(object sender, EventArgs e)
        {
            if (this.ComboRepository.SelectedIndex < 0)
            {
                MessageBox.Show("Select the repository");
                return;
            }

            if (!this.inputControl.ValidateInputs())
            {
                return;
            }

            RepositoryType repositoryType = (RepositoryType) this.ComboRepository.SelectedItem;
            BaseFactory controlFactory = BaseFactory.GetControlFactory(repositoryType);
            IRepositoryAdapter repoAdapter = (IRepositoryAdapter)controlFactory.CreateRepositoryAdapter();
            
            if (repoAdapter != null)
            {
                this.EnableControls(false);
                BindingSource bindingSource = new BindingSource();
                DateTime startTime = DateTime.Now;
                bindingSource.DataSource = repoAdapter.FetchDocuments(this.inputControl.Parameters);
                DateTime endTime = DateTime.Now;
                TimeSpan elapsedTime = new TimeSpan(endTime.Ticks - startTime.Ticks);
                this.StatusLabel.Text = string.Format("Records Fetched : {0}, Time taken for operation : {1} seconds", bindingSource.Count.ToString(), elapsedTime.TotalSeconds.ToString());
                this.DataGridRecords.DataSource = bindingSource;
                this.EnableControls(true);
            }
        }

        /// <summary>
        /// Handles the Click event of the ButtonImportData control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ButtonImportData_Click(object sender, EventArgs e)
        {
            this.EnableControls(false);
            BindingSource bindingSource = this.DataGridRecords.DataSource as BindingSource;
            IEnumerable<Journal> researchDocuments = bindingSource.DataSource as IEnumerable<Journal>;
            using (ZentityContext zentityContext = new ZentityContext())
            {
                DateTime startTime = DateTime.Now;
                foreach (Journal resDocument in researchDocuments)
                {
                    zentityContext.AddToResources(resDocument);
                }
                
                zentityContext.SaveChanges();

                foreach (Journal resDocument in researchDocuments)
                {
                    foreach (File file in resDocument.Files)
                    {
                        zentityContext.UploadFileContent(file, file.Uri);
                    }
                }
                
                DateTime endTime = DateTime.Now;
                TimeSpan elapsedTime = new TimeSpan(endTime.Ticks - startTime.Ticks);
                this.StatusLabel.Text = string.Format("Records Imported to Zentity : {0}, Time taken for operation : {1} seconds", bindingSource.Count.ToString(), elapsedTime.TotalSeconds.ToString());
            }

            this.DataGridRecords.DataSource = null;
            this.EnableControls(true);
        }

        /// <summary>
        /// Enables the controls.
        /// </summary>
        /// <param name="enableFlag">if set to <c>true</c> [enable flag].</param>
        private void EnableControls(bool enableFlag)
        {
            this.ComboRepository.Enabled = enableFlag;
            this.ButtonFetchData.Enabled = enableFlag;
            this.ButtonImportData.Enabled = enableFlag;
            this.ButtonGetData.Enabled = enableFlag;
            this.ButtonDeleteData.Enabled = enableFlag;
            if (this.inputControl != null)
            {
                this.inputControl.Enabled = enableFlag;
            }
        }

        /// <summary>
        /// Handles the CellFormatting event of the DataGridRecords control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Forms.DataGridViewCellFormattingEventArgs"/> instance containing the event data.</param>
        private void DataGridRecords_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.DataGridRecords.Columns[e.ColumnIndex].Name == "Authors")
            {
                e.FormattingApplied = true;
                DataGridViewRow row = DataGridRecords.Rows[e.RowIndex];
                Journal resDocument = row.DataBoundItem as Journal;
                if (resDocument != null)
                {
                    StringBuilder authorNames = new StringBuilder();
                    foreach (Person author in resDocument.Authors)
                    {
                        authorNames.AppendFormat("{0} {1}, ", author.FirstName, author.LastName);
                    }

                    e.Value = authorNames.ToString();
                }
            }

            if (this.DataGridRecords.Columns[e.ColumnIndex].Name == "Files")
            {
                e.FormattingApplied = true;
                DataGridViewRow row = DataGridRecords.Rows[e.RowIndex];
                Journal resDocument = row.DataBoundItem as Journal;
                if (resDocument != null)
                {
                    e.Value = resDocument.Files.Count.ToString(CultureInfo.InvariantCulture);
                }
            }
        }

        /// <summary>
        /// Handles the Click event of the ButtonGetData control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ButtonGetData_Click(object sender, EventArgs e)
        {
            this.EnableControls(false);
            using (ZentityContext zentityContext = new ZentityContext())
            {
                BindingSource bindingSource = new BindingSource();
                DateTime startTime = DateTime.Now;

                Type researchDocType = Type.GetType("Zentity.ScholarlyWorks.Journal, Zentity.ScholarlyWorks", false);
                Type resourceCollectionType = typeof(System.Data.Objects.ObjectQuery<Resource>);
                MethodInfo[] arrMethods = resourceCollectionType.GetMethods();
                MethodInfo ofTypeMethod = resourceCollectionType.GetMethod("OfType"); //arrMethods.First(mi => mi.Name.Equals("OfType"));
                if (ofTypeMethod != null && researchDocType != null)
                {
                    MethodInfo genericMethod = ofTypeMethod.MakeGenericMethod(new Type[] { researchDocType });
                    if (genericMethod != null)
                    {
                        var resDocuments = genericMethod.Invoke(zentityContext.Resources, null) as IEnumerable;
                        foreach (Journal resDocument in resDocuments)
                        {
                            resDocument.Authors.Load();
                            resDocument.Files.Load();
                        }

                        bindingSource.DataSource = resDocuments;
                        this.DataGridRecords.DataSource = bindingSource;
                    }
                }

                IEnumerable<Journal> researchDocuments = zentityContext.Resources.OfType<Journal>();
                foreach (Journal resDocument in researchDocuments)
                {
                    resDocument.Authors.Load();
                    resDocument.Files.Load();
                }

                bindingSource.DataSource = researchDocuments;
                this.DataGridRecords.DataSource = bindingSource;
                DateTime endTime = DateTime.Now;
                TimeSpan elapsedTime = new TimeSpan(endTime.Ticks - startTime.Ticks);
                this.StatusLabel.Text = string.Format("Records Fetched from Zentity : {0}, Time taken for operation : {1} seconds", bindingSource.Count.ToString(), elapsedTime.TotalSeconds.ToString());
            }

            this.EnableControls(true);
        }

        /// <summary>
        /// Handles the Click event of the ButtonDeleteData control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ButtonDeleteData_Click(object sender, EventArgs e)
        {
            DateTime startTime = DateTime.Now;
            int count = 0;
            this.EnableControls(false);
            using (ZentityContext zentityContext = new ZentityContext())
            {
                IEnumerable<Journal> researchDocuments = zentityContext.Resources.OfType<Journal>();
                count = researchDocuments.Count();
                foreach (Journal resDocument in researchDocuments)
                {

                    resDocument.RelationshipsAsSubject.Load();
                    while (resDocument.RelationshipsAsSubject.Count > 0)
                    {
                        zentityContext.DeleteObject(resDocument.RelationshipsAsSubject.First());
                    
                    }

                    resDocument.RelationshipsAsObject.Load();
                    while (resDocument.RelationshipsAsObject.Count > 0)
                    {
                        zentityContext.DeleteObject(resDocument.RelationshipsAsObject.First());
                    }

                    resDocument.Authors.Load();
                    resDocument.Files.Load();
                    
                    while (resDocument.Authors.Count > 0)
                    {
                        zentityContext.DeleteObject(resDocument.Authors.First());
                    }

                    while (resDocument.Files.Count > 0)
                    {
                        zentityContext.DeleteObject(resDocument.Files.First());
                    }
                    
                    zentityContext.DeleteObject(resDocument);
                }

                ////IEnumerable<Author> researchAuthors = zentityContext.Resources.OfType<Author>();
                ////foreach (Author docAuthor in researchAuthors)
                ////{
                ////    zentityContext.DeleteObject(docAuthor);
                ////}

                zentityContext.SaveChanges();
                DateTime endTime = DateTime.Now;
                TimeSpan elapsedTime = new TimeSpan(endTime.Ticks - startTime.Ticks);
                this.StatusLabel.Text = string.Format("Records Deleted from Zentity : {0}, Time taken for operation : {1} seconds", count, elapsedTime.TotalSeconds.ToString());
            }

            this.DataGridRecords.DataSource = null;
            this.EnableControls(true);
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the ComboRepository control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void ComboRepository_SelectedIndexChanged(object sender, EventArgs e)
        {
            RepositoryType repositoryType = (RepositoryType)this.ComboRepository.SelectedItem;
            BaseFactory controlFactory = BaseFactory.GetControlFactory(repositoryType);
            if (controlFactory != null)
            {
                this.Controls.Remove(this.inputControl);
                this.inputControl = controlFactory.CreateControl();
                this.inputControl.Top = LabelRepository.Top + 40;
                this.inputControl.Left = LabelRepository.Left;
                this.Controls.Add(this.inputControl);
            }
        }
    }
}
