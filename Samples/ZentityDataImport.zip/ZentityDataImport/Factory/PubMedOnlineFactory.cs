﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace ZentityDataImport
{
    using ZentityDataImport.Control;
    using ZentityDataImport.Repository;

    /// <summary>
    /// Defines the Factory class for the PubMed Repository specific controls and functionality
    /// </summary>
    internal class PubMedOnlineFactory : BaseFactory
    {
        /// <summary>
        /// Initializes static members of the <see cref="PubMedOnlineFactory"/> class.
        /// </summary>
        static PubMedOnlineFactory()
        {
            PubMedOnlineFactory.RepositoryType = RepositoryType.PubMedOnline;
        }

        /// <summary>
        /// Gets or sets the type of the repository.
        /// </summary>
        /// <value>The type of the repository.</value>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called through reflection.")]
        public static RepositoryType RepositoryType
        {
            get;
            protected set;
        }

        /// <summary>
        /// Registers this class in the control map.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called through reflection.")]
        public static void Register()
        {
            BaseFactory.FactoryMap.Add(PubMedOnlineFactory.RepositoryType, new PubMedOnlineFactory());
        }

        /// <summary>
        /// Creates the user control.
        /// </summary>
        /// <returns>BaseInputControl type control instance</returns>
        public override BaseInputControl CreateControl()
        {
            return new PubMedOnlineInputControl();
        }

        /// <summary>
        /// Creates the repository adapter.
        /// </summary>
        /// <returns>IRepositoryAdapter type instance</returns>
        public override IRepositoryAdapter CreateRepositoryAdapter()
        {
            return new PubMedRepository();
        }
    }
}
