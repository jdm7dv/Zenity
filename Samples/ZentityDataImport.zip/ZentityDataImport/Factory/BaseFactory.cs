﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace ZentityDataImport
{
    using System.Collections.Generic;
    using ZentityDataImport.Control;
    using ZentityDataImport.Repository;

    /// <summary>
    /// Defines the Abstract Base Factory class for the Repository specific controls and functionality
    /// </summary>
    public abstract class BaseFactory
    {
        /// <summary>
        /// Dictionary object to hold the Factory Map
        /// </summary>
        private static Dictionary<RepositoryType, BaseFactory> factoryMap = new Dictionary<RepositoryType, BaseFactory>();

        /// <summary>
        /// Gets the factory map.
        /// </summary>
        /// <value>The factory map.</value>
        protected static Dictionary<RepositoryType, BaseFactory> FactoryMap
        {
            get
            {
                return factoryMap;
            }
        }

        /// <summary>
        /// Gets the control factory.
        /// </summary>
        /// <param name="repositoryKey">The repository type key.</param>
        /// <returns>Returns the specific factory class from the map based on the key</returns>
        public static BaseFactory GetControlFactory(RepositoryType repositoryKey)
        {
            if (BaseFactory.FactoryMap.ContainsKey(repositoryKey))
            {
                return FactoryMap[repositoryKey];
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Creates the user control.
        /// </summary>
        /// <returns>BaseInputControl type control instance</returns>
        public abstract BaseInputControl CreateControl();

        /// <summary>
        /// Creates the repository adapter.
        /// </summary>
        /// <returns>IRepositoryAdapter type instance</returns>
        public abstract IRepositoryAdapter CreateRepositoryAdapter();
    }
}
