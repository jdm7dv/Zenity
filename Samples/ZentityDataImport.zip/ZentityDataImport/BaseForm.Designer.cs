﻿
namespace ZentityDataImport
{
    /// <summary>
    /// Base Windows Form for the Data Import Application
    /// </summary>
    public partial class BaseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LabelRepository = new System.Windows.Forms.Label();
            this.ComboRepository = new System.Windows.Forms.ComboBox();
            this.ButtonFetchData = new System.Windows.Forms.Button();
            this.DataGridRecords = new System.Windows.Forms.DataGridView();
            this.ButtonImportData = new System.Windows.Forms.Button();
            this.ButtonGetData = new System.Windows.Forms.Button();
            this.ButtonDeleteData = new System.Windows.Forms.Button();
            this.StatusStrip = new System.Windows.Forms.StatusStrip();
            this.StatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.PublishedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Authors = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Files = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Abstract = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.License = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridRecords)).BeginInit();
            this.StatusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // LabelRepository
            // 
            this.LabelRepository.AutoSize = true;
            this.LabelRepository.Location = new System.Drawing.Point(29, 18);
            this.LabelRepository.Name = "LabelRepository";
            this.LabelRepository.Size = new System.Drawing.Size(91, 13);
            this.LabelRepository.TabIndex = 0;
            this.LabelRepository.Text = "Select Repository";
            // 
            // ComboRepository
            // 
            this.ComboRepository.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboRepository.FormattingEnabled = true;
            this.ComboRepository.Location = new System.Drawing.Point(174, 14);
            this.ComboRepository.Name = "ComboRepository";
            this.ComboRepository.Size = new System.Drawing.Size(242, 21);
            this.ComboRepository.TabIndex = 3;
            // 
            // ButtonFetchData
            // 
            this.ButtonFetchData.Location = new System.Drawing.Point(174, 151);
            this.ButtonFetchData.Name = "ButtonFetchData";
            this.ButtonFetchData.Size = new System.Drawing.Size(95, 24);
            this.ButtonFetchData.TabIndex = 6;
            this.ButtonFetchData.Text = "Fetch Data";
            this.ButtonFetchData.UseVisualStyleBackColor = true;
            this.ButtonFetchData.Click += new System.EventHandler(this.ButtonFetchData_Click);
            // 
            // DataGridRecords
            // 
            this.DataGridRecords.AllowUserToAddRows = false;
            this.DataGridRecords.AllowUserToDeleteRows = false;
            this.DataGridRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridRecords.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PublishedDate,
            this.Title,
            this.Authors,
            this.Files,
            this.Abstract,
            this.License});
            this.DataGridRecords.Location = new System.Drawing.Point(32, 200);
            this.DataGridRecords.MultiSelect = false;
            this.DataGridRecords.Name = "DataGridRecords";
            this.DataGridRecords.ReadOnly = true;
            this.DataGridRecords.RowHeadersVisible = false;
            this.DataGridRecords.Size = new System.Drawing.Size(770, 231);
            this.DataGridRecords.TabIndex = 7;
            this.DataGridRecords.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DataGridRecords_CellFormatting);
            // 
            // ButtonImportData
            // 
            this.ButtonImportData.Location = new System.Drawing.Point(290, 151);
            this.ButtonImportData.Name = "ButtonImportData";
            this.ButtonImportData.Size = new System.Drawing.Size(151, 24);
            this.ButtonImportData.TabIndex = 8;
            this.ButtonImportData.Text = "Import To Zentity";
            this.ButtonImportData.UseVisualStyleBackColor = true;
            this.ButtonImportData.Click += new System.EventHandler(this.ButtonImportData_Click);
            // 
            // ButtonGetData
            // 
            this.ButtonGetData.Location = new System.Drawing.Point(462, 151);
            this.ButtonGetData.Name = "ButtonGetData";
            this.ButtonGetData.Size = new System.Drawing.Size(151, 24);
            this.ButtonGetData.TabIndex = 9;
            this.ButtonGetData.Text = "Get Data From Zentity";
            this.ButtonGetData.UseVisualStyleBackColor = true;
            this.ButtonGetData.Click += new System.EventHandler(this.ButtonGetData_Click);
            // 
            // ButtonDeleteData
            // 
            this.ButtonDeleteData.Location = new System.Drawing.Point(634, 151);
            this.ButtonDeleteData.Name = "ButtonDeleteData";
            this.ButtonDeleteData.Size = new System.Drawing.Size(151, 24);
            this.ButtonDeleteData.TabIndex = 10;
            this.ButtonDeleteData.Text = "Delete Data From Zentity";
            this.ButtonDeleteData.UseVisualStyleBackColor = true;
            this.ButtonDeleteData.Click += new System.EventHandler(this.ButtonDeleteData_Click);
            // 
            // StatusStrip
            // 
            this.StatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusLabel});
            this.StatusStrip.Location = new System.Drawing.Point(0, 447);
            this.StatusStrip.Name = "StatusStrip";
            this.StatusStrip.Size = new System.Drawing.Size(830, 22);
            this.StatusStrip.SizingGrip = false;
            this.StatusStrip.TabIndex = 11;
            this.StatusStrip.Text = "statusStrip1";
            // 
            // StatusLabel
            // 
            this.StatusLabel.Name = "StatusLabel";
            this.StatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // PublishedDate
            // 
            this.PublishedDate.DataPropertyName = "DatePublished";
            this.PublishedDate.HeaderText = "PublishedDate";
            this.PublishedDate.Name = "PublishedDate";
            this.PublishedDate.ReadOnly = true;
            // 
            // Title
            // 
            this.Title.DataPropertyName = "Title";
            this.Title.HeaderText = "Title";
            this.Title.Name = "Title";
            this.Title.ReadOnly = true;
            this.Title.Width = 200;
            // 
            // Authors
            // 
            this.Authors.HeaderText = "Authors";
            this.Authors.Name = "Authors";
            this.Authors.ReadOnly = true;
            // 
            // Files
            // 
            this.Files.HeaderText = "Files";
            this.Files.Name = "Files";
            this.Files.ReadOnly = true;
            this.Files.Width = 50;
            // 
            // Abstract
            // 
            this.Abstract.DataPropertyName = "Abstract";
            this.Abstract.HeaderText = "Abstract";
            this.Abstract.Name = "Abstract";
            this.Abstract.ReadOnly = true;
            this.Abstract.Width = 200;
            // 
            // License
            // 
            this.License.DataPropertyName = "License";
            this.License.HeaderText = "License";
            this.License.Name = "License";
            this.License.ReadOnly = true;
            // 
            // BaseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(830, 469);
            this.Controls.Add(this.StatusStrip);
            this.Controls.Add(this.ButtonDeleteData);
            this.Controls.Add(this.ButtonGetData);
            this.Controls.Add(this.ButtonImportData);
            this.Controls.Add(this.DataGridRecords);
            this.Controls.Add(this.ButtonFetchData);
            this.Controls.Add(this.ComboRepository);
            this.Controls.Add(this.LabelRepository);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BaseForm";
            this.Text = "Zentity Data Import Tool";
            ((System.ComponentModel.ISupportInitialize)(this.DataGridRecords)).EndInit();
            this.StatusStrip.ResumeLayout(false);
            this.StatusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelRepository;
        private System.Windows.Forms.ComboBox ComboRepository;
        private System.Windows.Forms.Button ButtonFetchData;
        private System.Windows.Forms.Button ButtonImportData;
        private System.Windows.Forms.DataGridView DataGridRecords;
        private System.Windows.Forms.Button ButtonGetData;
        private System.Windows.Forms.Button ButtonDeleteData;
        private System.Windows.Forms.StatusStrip StatusStrip;
        private System.Windows.Forms.ToolStripStatusLabel StatusLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn PublishedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn Authors;
        private System.Windows.Forms.DataGridViewTextBoxColumn Files;
        private System.Windows.Forms.DataGridViewTextBoxColumn Abstract;
        private System.Windows.Forms.DataGridViewTextBoxColumn License;
    }
}
