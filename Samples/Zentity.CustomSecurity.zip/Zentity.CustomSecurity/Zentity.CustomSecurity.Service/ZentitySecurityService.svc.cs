﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace Zentity.CustomSecurity.Service
{
    using System.Security.Permissions;

    public class ZentitySecurityService : IZentitySecurityService
    {
        [PrincipalPermission(SecurityAction.Demand, Role = "ZentityAdministrators")]
        public string GetDataForZentityAdmin()
        {
            return string.Format("Hello Zentity Administrator!");
        }

        [PrincipalPermission(SecurityAction.Demand, Role = "ZentityAdministrators")]
        [PrincipalPermission(SecurityAction.Demand, Role = "ZentityUsers")]
        public string GetDataForZentityUser()
        {
            return string.Format("Hello Zentity User!");
        }
    }
}
