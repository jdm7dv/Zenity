﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace Zentity.CustomSecurity.Service
{
    using System.ServiceModel;

    [ServiceContract]
    public interface IZentitySecurityService
    {
        [OperationContract]
        string GetDataForZentityAdmin();

        [OperationContract]
        string GetDataForZentityUser();
    }
}