Create database [ZentitySecurity]
GO
USE [ZentitySecurity]
GO
CREATE TABLE [dbo].[ZentityUser](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[Password] [nvarchar](20) NOT NULL,
	[IsAdmin] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT INTO [ZentitySecurity].[dbo].[ZentityUser]([UserName],[Password],[IsAdmin]) VALUES('Administrator','admin@123',1)
GO
INSERT INTO [ZentitySecurity].[dbo].[ZentityUser]([UserName],[Password],[IsAdmin]) VALUES('User','user@123',0)
GO