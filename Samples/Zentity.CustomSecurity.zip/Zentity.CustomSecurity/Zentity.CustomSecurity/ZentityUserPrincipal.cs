﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace Zentity.CustomSecurity
{
    using System.Linq;
    using System.Security.Principal;
    
    /// <summary>
    /// Custom Principal object
    /// </summary>
    public class ZentityUserPrincipal : IPrincipal
    {
        string[] roles;
        IIdentity identity;

        public ZentityUserPrincipal(IIdentity userIdentity, string[] userRoles)
        {
            identity = userIdentity;
            roles = userRoles;

        }

        /// <summary>
        /// Gets the identity of the current principal.
        /// </summary>
        public IIdentity Identity
        {
            get { return identity; }
        }

        /// <summary>
        /// Determines whether the current principal belongs to the specified role.
        /// </summary>
        /// <param name="role">The name of the role for which to check membership.</param>
        /// <returns>True if the current principal is a member of the specified role; otherwise false.</returns>
        public bool IsInRole(string role)
        {
            bool userIsInRole = false;
            if (roles.Contains<string>(role))
                userIsInRole = true;

            return userIsInRole;
        }
    }
}