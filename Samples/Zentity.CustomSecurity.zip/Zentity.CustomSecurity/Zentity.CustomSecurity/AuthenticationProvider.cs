﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace Zentity.CustomSecurity
{
    using System;
    using System.IdentityModel.Selectors;
    using System.IdentityModel.Tokens;
    using System.Linq;
    using Zentity.CustomSecurity.DataLayer;

    /// <summary>
    /// Custom Authentication provider for validating username and password.
    /// </summary>
    class AuthenticationProvider : UserNamePasswordValidator
    {
        /// <summary>
        /// Validates the specified username and password.
        /// </summary>
        /// <param name="userName">Username to validate.</param>
        /// <param name="password">Password to validate.</param>
        public override void Validate(string userName, string password)
        {
            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(password))
                throw new ArgumentNullException("Username and password required");

            ZentityUser clientUser = null;
            using (ZentitySecurityDataContext zentitysecurity = new ZentitySecurityDataContext())
            {
                clientUser = zentitysecurity.ZentityUsers.Where(user => user.UserName.Equals(userName) && user.Password.Equals(password)).FirstOrDefault();
            }

            if (clientUser == null)
                throw new SecurityTokenException("User not authorized to access this service");
        }
    }
}
