﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace Zentity.CustomSecurity
{
    using System;
    using System.Collections.Generic;
    using System.IdentityModel.Claims;
    using System.IdentityModel.Policy;
    using System.Linq;
    using System.Security.Principal;
    using Zentity.CustomSecurity.DataLayer;

    /// <summary>
    /// Defines a set of rules for authorizing a user, given a set of claims.
    /// </summary>
    class AuthorizationProvider : IAuthorizationPolicy
    {
        Guid id = Guid.NewGuid();

        /// <summary>
        /// Evaluates whether a user meets the requirements for this authorization policy.
        /// </summary>
        /// <param name="evaluationContext">An System.IdentityModel.Policy.EvaluationContext that contains the claim set that the authorization policy evaluates.</param>
        /// <param name="state">A System.Object, passed by reference that represents the custom state for this authorization policy.</param>
        /// <returns>
        /// false if the System.IdentityModel.Policy.IAuthorizationPolicy.Evaluate(System.IdentityModel.Policy.EvaluationContext,System.Object@)
        ///     method for this authorization policy must be called if additional claims
        ///     are added by other authorization policies to evaluationContext; otherwise,
        ///     true to state no additional evaluation is required by this authorization
        ///    policy.</returns>
        public bool Evaluate(EvaluationContext evaluationContext, ref object state)
        {
            IIdentity clientIdentity = GetClientIdentity(evaluationContext);
            string loggedInUser = clientIdentity.Name;
            bool role = false;
            using (ZentitySecurityDataContext zentitySecurity = new ZentitySecurityDataContext())
            {
                ZentityUser clientUser = zentitySecurity.ZentityUsers.Where(user => user.UserName.Equals(loggedInUser)).FirstOrDefault();
                role = clientUser == null ? false : clientUser.IsAdmin;
            }

            evaluationContext.Properties["Principal"] = new ZentityUserPrincipal(clientIdentity, new string[] { role ? "ZentityAdministrators" : "ZentityUsers" });
            return true;
        }

        /// <summary>
        /// Gets the identity of the client.
        /// </summary>
        /// <param name="evaluationContext">An System.IdentityModel.Policy.EvaluationContext that contains the claim set that the authorization policy evaluates.</param>
        /// <returns>Identity of the current user.</returns>
        private IIdentity GetClientIdentity(EvaluationContext evaluationContext)
        {
            object obj;
            if (!evaluationContext.Properties.TryGetValue("Identities", out obj))
                throw new Exception("No Identity found");

            IList<IIdentity> identities = obj as IList<IIdentity>;
            if (identities == null || identities.Count <= 0)
                throw new Exception("No Identity found");

            return identities[0];
        }

        /// <summary>
        ///  Gets a claim set that represents the issuer of the authorization policy.
        /// </summary>
        public System.IdentityModel.Claims.ClaimSet Issuer
        {
            get { return ClaimSet.System; }
        }

        public string Id
        {
            get { return id.ToString(); }
        }
    }
}
