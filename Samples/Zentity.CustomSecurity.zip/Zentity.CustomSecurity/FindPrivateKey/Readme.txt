====================
FindPrivateKey.exe
====================
This tool will find the location of the private key of a Certificate that is intalled on the current machine.

======================
Download Details
======================
FindPrivateKey.exe is available as a part of "Windows Communication Foundation (WCF) and Windows Workflow Foundation (WF) Samples for .NET Framework 4"
http://www.microsoft.com/downloads/en/details.aspx?FamilyID=35ec8682-d5fd-4bc3-a51a-d8ad115a8792&displaylang=en