﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace Zentity.CustomSecurity.EndpointBehavior
{
    using System;
    using System.Configuration;
    using System.ServiceModel.Configuration;
    using System.ServiceModel.Description;

    class ZentityUserNameBehavior : IEndpointBehavior
    {
        public void AddBindingParameters(ServiceEndpoint endpoint, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.ClientRuntime clientRuntime)
        {
            ClientCredentials clientCredentials = endpoint.Behaviors.Find<ClientCredentials>();
            if (string.IsNullOrWhiteSpace(ZentityUser.ZentityUserName) || string.IsNullOrWhiteSpace(ZentityUser.ZentityPassword))
            {
                string zentityUserName = ConfigurationManager.AppSettings["ZentityUserName"];
                string zentityPassword = ConfigurationManager.AppSettings["ZentityPassword"];
                if (!string.IsNullOrWhiteSpace(zentityUserName) && !string.IsNullOrWhiteSpace(zentityPassword))
                {
                    clientCredentials.UserName.UserName = zentityUserName;
                    clientCredentials.UserName.Password = zentityPassword;
                }
            }
            else
            {
                clientCredentials.UserName.UserName = ZentityUser.ZentityUserName;
                clientCredentials.UserName.Password = ZentityUser.ZentityPassword;
            }
        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.EndpointDispatcher endpointDispatcher)
        {
        }

        public void Validate(ServiceEndpoint endpoint)
        {
        }
    }

    public class ZentityUserNameBehaviorElement : BehaviorExtensionElement
    {
        protected override object CreateBehavior()
        {
            return new ZentityUserNameBehavior();
        }

        public override Type BehaviorType
        {
            get { return typeof(ZentityUserNameBehavior); }
        }
    }
}
