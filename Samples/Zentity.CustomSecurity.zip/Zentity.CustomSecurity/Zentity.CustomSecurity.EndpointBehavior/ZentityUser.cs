﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace Zentity.CustomSecurity.EndpointBehavior
{
    public static class ZentityUser
    {
        public static string ZentityUserName
        {
            get;
            set;
        }

        public static string ZentityPassword
        {
            get;
            set;
        }
    }
}
