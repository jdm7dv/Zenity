﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************


namespace Zentity.CustomSecurity.Client.Console
{
    using System;
    using Zentity.CustomSecurity.Client.Console.ZentitySecurityServiceReference;
    using Zentity.CustomSecurity.EndpointBehavior;

    class Program
    {
        static void Main(string[] args)
        {
            string yesNo = "N";
            do
            {
                Execute();
                System.Console.WriteLine("\nRun client again(Y / N): ");
                yesNo = System.Console.ReadLine();
            } while (yesNo.Equals("Y", StringComparison.OrdinalIgnoreCase));
        }

        static void Execute()
        {
            System.Console.WriteLine("Options: \n1.Run client with admin privileges \n2.Run client with user privileges \n3.Run client with custom user\n");
            string option = System.Console.ReadLine();
            switch (option)
            {
                case "1":
                    RunClientAsAdministrator();
                    break;
                case "2":
                    RunClientAsUser();
                    break;
                case "3":
                    RunClientAsSpecifiedUser();
                    break;
                default:
                    Execute();
                    break;
            }
        }

        static void RunClientAsAdministrator()
        {
            try
            {
                using (ZentitySecurityServiceClient client = new ZentitySecurityServiceClient())
                {
                    ZentityUser.ZentityUserName = "Administrator";
                    ZentityUser.ZentityPassword = "admin@123";
                    System.Console.WriteLine(client.GetDataForZentityAdmin());
                    System.Console.WriteLine(client.GetDataForZentityUser());
                }
            }
            catch (System.ServiceModel.FaultException ex)
            {
                System.Console.WriteLine(ex.ToString());
            }
            catch (System.ServiceModel.CommunicationObjectFaultedException)
            {
                System.Console.WriteLine("Username not found or does not exists.");
            }
            catch (System.ServiceModel.Security.SecurityAccessDeniedException)
            {
                System.Console.WriteLine("The specified user does not have zentity administrator privileges to access the specified function.");
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.ToString());
            }
        }

        static void RunClientAsUser()
        {
            try
            {
                using (ZentitySecurityServiceClient client = new ZentitySecurityServiceClient())
                {
                    ZentityUser.ZentityUserName = "User";
                    ZentityUser.ZentityPassword = "user@123";
                    System.Console.WriteLine(client.GetDataForZentityUser());
                    System.Console.WriteLine(client.GetDataForZentityAdmin());
                }
            }
            catch (System.ServiceModel.FaultException ex)
            {
                System.Console.WriteLine(ex.ToString());
            }
            catch (System.ServiceModel.CommunicationObjectFaultedException)
            {
                System.Console.WriteLine("Username not found or does not exists.");
            }
            catch (System.ServiceModel.Security.SecurityAccessDeniedException)
            {
                System.Console.WriteLine("The specified user does not have zentity administrator privileges to access the specified function.");
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.ToString());
            }
        }

        static void RunClientAsSpecifiedUser()
        {
            System.Console.WriteLine("Enter Zentity User Name: ");
            string userName = System.Console.ReadLine();
            System.Console.WriteLine("Enter Zentity User Password: ");
            string password = System.Console.ReadLine();
            if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(password))
            {
                System.Console.WriteLine("UserName or Password provided is empty. Try again with valid values.");
                return;
            }

            try
            {
                using (ZentitySecurityServiceClient client = new ZentitySecurityServiceClient())
                {
                    ZentityUser.ZentityUserName = userName;
                    ZentityUser.ZentityPassword = password;
                    System.Console.WriteLine(client.GetDataForZentityUser());
                    System.Console.WriteLine(client.GetDataForZentityAdmin());
                }
            }
            catch (System.ServiceModel.FaultException ex)
            {
                System.Console.WriteLine(ex.ToString());
            }
            catch (System.ServiceModel.CommunicationObjectFaultedException)
            {
                System.Console.WriteLine("Username not found or does not exists.");
            }
            catch (System.ServiceModel.Security.SecurityAccessDeniedException)
            {
                System.Console.WriteLine("The specified user does not have zentity administrator privileges to access the specified function.");
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.ToString());
            }
        }
    }
}
