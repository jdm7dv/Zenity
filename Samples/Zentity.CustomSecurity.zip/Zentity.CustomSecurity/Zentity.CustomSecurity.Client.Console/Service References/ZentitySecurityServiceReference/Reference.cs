﻿// *******************************************************
//                                                        
//    Copyright (C) Microsoft. All rights reserved.       
//                                                        
// *******************************************************

namespace Zentity.CustomSecurity.Client.Console.ZentitySecurityServiceReference {
    
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    [System.ServiceModel.ServiceContractAttribute(ConfigurationName="ZentitySecurityServiceReference.IZentitySecurityService")]
    public interface IZentitySecurityService {
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IZentitySecurityService/GetDataForZentityAdmin", ReplyAction="http://tempuri.org/IZentitySecurityService/GetDataForZentityAdminResponse")]
        string GetDataForZentityAdmin();
        
        [System.ServiceModel.OperationContractAttribute(Action="http://tempuri.org/IZentitySecurityService/GetDataForZentityUser", ReplyAction="http://tempuri.org/IZentitySecurityService/GetDataForZentityUserResponse")]
        string GetDataForZentityUser();
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public interface IZentitySecurityServiceChannel : Zentity.CustomSecurity.Client.Console.ZentitySecurityServiceReference.IZentitySecurityService, System.ServiceModel.IClientChannel {
    }
    
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.ServiceModel", "4.0.0.0")]
    public partial class ZentitySecurityServiceClient : System.ServiceModel.ClientBase<Zentity.CustomSecurity.Client.Console.ZentitySecurityServiceReference.IZentitySecurityService>, Zentity.CustomSecurity.Client.Console.ZentitySecurityServiceReference.IZentitySecurityService {
        
        public ZentitySecurityServiceClient() {
        }
        
        public ZentitySecurityServiceClient(string endpointConfigurationName) : 
                base(endpointConfigurationName) {
        }
        
        public ZentitySecurityServiceClient(string endpointConfigurationName, string remoteAddress) : 
                base(endpointConfigurationName, remoteAddress) {
        }
        
        public ZentitySecurityServiceClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) : 
                base(endpointConfigurationName, remoteAddress) {
        }
        
        public ZentitySecurityServiceClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) : 
                base(binding, remoteAddress) {
        }
        
        public string GetDataForZentityAdmin() {
            return base.Channel.GetDataForZentityAdmin();
        }
        
        public string GetDataForZentityUser() {
            return base.Channel.GetDataForZentityUser();
        }
    }
}
