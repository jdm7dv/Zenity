1. Run authentication and authorization database scripts. (Found in program files\Zentity 1.0\Scripts)
2. Open solution in Visual Studio 2008
2. Check and modify connection string in app.config
3. Build and run the sample.