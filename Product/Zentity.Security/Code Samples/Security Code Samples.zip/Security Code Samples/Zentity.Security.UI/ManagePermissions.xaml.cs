﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zentity.Security.Management;
using System.Configuration;
using System.Collections.ObjectModel;
using System.Collections;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for ManagePermissions.xaml
    /// </summary>
    public partial class ManagePermissions : UserControl
    {
        private string currentName;
        private ResourceType currentType;
        private int startIndex;
        private int pageSize;
        private bool eof;
        private bool eob;
        private AuthorizationManager manager;
        private Main parentWindow;

        public ManagePermissions(Main parentWindow)
        {
            InitializeComponent();
            this.parentWindow = parentWindow;
            string connStr = ConfigurationManager.ConnectionStrings["AuthorizationStore"].ConnectionString;
            manager = new AuthorizationManager(connStr);
            txtGroupName.Focus();
        }

        private void btnGetPermissionMap_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                parentWindow.Cursor = Cursors.Wait;                
                SetPageSize();
                switch (currentType)
                {
                    case ResourceType.Identity:
                        currentName = txtIdentityName.Text.Trim();
                        break;

                    case ResourceType.Group:
                        currentName = txtGroupName.Text.Trim();
                        break;
                }
                if (string.IsNullOrEmpty(currentName))
                {
                    MessageBox.Show("Specify a valid Group/Identity.", "Manage Permissions", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                lstBoxPermissionsMap.ItemsSource =
                       manager.GetResourcePermissionMap
                                   (currentName, currentType, startIndex, pageSize);
                btnGetPermissionMap.IsEnabled = false;
                parentWindow.Cursor = Cursors.Arrow;
            }
            catch (ArgumentException exp)
            {
                MessageBox.Show(exp.Message, "Manage Permissions", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                parentWindow.Cursor = Cursors.Arrow;
            }
        }

        private void lblNext_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(currentName) && !eof)
            {
                SetPageSize();
                startIndex += pageSize;
                parentWindow.Cursor = Cursors.Wait;
                IEnumerable<ResourcePermissionMap> map =
                    manager.GetResourcePermissionMap(currentName, currentType, startIndex, pageSize);
                parentWindow.Cursor = Cursors.Arrow;
                if (map.Count() == 0)
                {
                    eof = true;
                }
                else
                {
                    lstBoxPermissionsMap.ItemsSource = map;
                }
            }
        }

        private void lblPrevious_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(currentName) && !eob)
            {
                SetPageSize();
                startIndex -= pageSize;
                if (startIndex < 0)
                {
                    eob = true;
                }
                else
                {
                    parentWindow.Cursor = Cursors.Wait;                    
                    lstBoxPermissionsMap.ItemsSource =
                        manager.GetResourcePermissionMap(currentName, currentType, startIndex, pageSize);
                    parentWindow.Cursor = Cursors.Arrow;
                }
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtGroupName.Text = string.Empty;
            txtIdentityName.Text = string.Empty;            
            lstBoxPermissionsMap.ItemsSource = null;
            eof = false;
            eob = false;
            currentName = string.Empty;            
            this.btnClear.IsEnabled = false;
        }                

        private void btnEditPermissionMap_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            ResourcePermissionMap map = btn.DataContext as ResourcePermissionMap;
            Permissions permissions = new Permissions(map);
            if (permissions.ShowDialog().Value)
            {
                ResourcePermissionMap updatedMap = permissions.map;
                string updatedPermissionStr = map.PermissionsStr;
                try
                {
                    parentWindow.Cursor = Cursors.Wait;
                    manager.AssignPermissionsOnResource(
                                                    currentName,
                                                    map.ResourceId,
                                                    map.Permissions,
                                                    currentType);
                    MessageBox.Show("Permissions updated successfully", "Manage Permissions", MessageBoxButton.OK, MessageBoxImage.Information);
                    StackPanel panel = btn.Parent as StackPanel;
                    ((TextBlock)panel.Children[1]).Text = updatedPermissionStr;                    
                }
                catch (ArgumentException exp)
                {
                    MessageBox.Show(exp.Message, "Manage Permissions", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    parentWindow.Cursor = Cursors.Arrow;
                }
            }
        }

        private void btnAddNew_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(currentName))
            {
                MessageBox.Show("Specify a valid Group/Identity.", "Manage Permissions", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Permissions permissions = new Permissions();
            if (permissions.ShowDialog().Value)
            {
                ResourcePermissionMap map = permissions.map;
                try
                {
                    parentWindow.Cursor = Cursors.Wait;
                    manager.AssignPermissionsOnResource(
                                                currentName,
                                                map.ResourceTitle,
                                                map.Permissions,
                                                currentType);
                    
                    map.ResourceId = manager.GetResourceId(map.ResourceTitle);
                    ICollection<ResourcePermissionMap> mapColl =
                        lstBoxPermissionsMap.ItemsSource as ICollection<ResourcePermissionMap>;
                    if (mapColl != null)
                    {
                        mapColl.Add(map);
                        lstBoxPermissionsMap.ItemsSource = null;
                        lstBoxPermissionsMap.ItemsSource = mapColl;
                    }

                }
                catch (ArgumentException exp)
                {
                    MessageBox.Show(exp.Message, "Manage Permissions", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    parentWindow.Cursor = Cursors.Arrow;
                }
            }
        }

        private void SetPageSize()
        {
            ComboBoxItem item = cmbPageSize.SelectedItem as ComboBoxItem;
            if (item != null)
            {
                int.TryParse(item.Content.ToString(), out pageSize);
            }
        }

        private void txtIdentityName_KeyDown(object sender, KeyEventArgs e)
        {
            int keyValue = (int)e.Key;
            if (keyValue >= 34 && keyValue <= 69)
            {
                btnGetPermissionMap.IsEnabled = true;
                btnAddNew.IsEnabled = true;
                btnClear.IsEnabled = true;                                
                currentType = ResourceType.Identity;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtGroupName_KeyDown(object sender, KeyEventArgs e)
        {
             int keyValue = (int)e.Key;
             if (keyValue >= 34 && keyValue <= 69)
             {
                 btnGetPermissionMap.IsEnabled = true;
                 btnClear.IsEnabled = true;
                 btnAddNew.IsEnabled = true;                 
                 currentType = ResourceType.Group;
             }
             else
             {
                 e.Handled = true;
             }
        }        
    }
}
