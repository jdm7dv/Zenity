﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Markup;
using System.Xml;
using System.IO;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for Main.xaml
    /// </summary>
    public partial class Main : Window
    {
        UserRegistration crtIdentity;
        UpdateProfile updateProfile;
        RegisterIdentity regIdentity;
        ManagePermissions mngPermissions;
        ManageGroups mngGroups;
        ManageAccount manageAccount;
        Unsubscribe unsubscribe;
        bool loggedIn;
        Label currentSelectedLink;

        public Main()
        {
            InitializeComponent();
        }

        private void Label_MouseEnter(object sender, MouseEventArgs e)
        {
            Label label = sender as Label;
            if (label != null && label != currentSelectedLink)
            {
                label.Style = null;
                label.Style = this.Resources["FocusedLabel"] as Style;
            }
        }

        private void Label_MouseLeave(object sender, MouseEventArgs e)
        {
            Label label = sender as Label;
            if (label != null && label != currentSelectedLink)
            {
                label.Style = this.Resources["UnFocusedLabel"] as Style;
            }
        }

        private void lblUserRegistration_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            SetLabelStyles("lblUserRegistration");
            if (crtIdentity == null)
            {
                crtIdentity = new UserRegistration(this);
            }
            this.contentPanel.Child = crtIdentity;
        }

        private void lblManageAccount_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            SetLabelStyles("lblManageAccount");
            if (manageAccount == null)
            {
                manageAccount = new ManageAccount(this);
            }
            this.contentPanel.Child = manageAccount;
        }

        private void lblUnsubscribe_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            SetLabelStyles("lblUnsubscribe");
            if (unsubscribe == null)
            {
                unsubscribe = new Unsubscribe(this);
            }
            this.contentPanel.Child = unsubscribe;
        }

        private void lblUpdateIdentity_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (updateProfile == null)
            {
                updateProfile = new UpdateProfile(this);
            }
            this.contentPanel.Child = updateProfile;
            SetLabelStyles("lblUpdateIdentity");
        }

        private void lblRegisterIdentity_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (!loggedIn)
            {
                Login loginWindow = new Login();
                loggedIn = loginWindow.ShowDialog().Value;
                if (!loggedIn)
                {
                    return;
                }
            }
            if (regIdentity == null)
            {
                regIdentity = new RegisterIdentity(this);
            }
            this.contentPanel.Child = regIdentity;
            SetLabelStyles("lblRegisterIdentity");
        }

        private void lblManagePermissions_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (!loggedIn)
            {
                Login loginWindow = new Login();
                loggedIn = loginWindow.ShowDialog().Value;
                if (!loggedIn)
                {
                    return;
                }
            }
            if (mngPermissions == null)
            {
                mngPermissions = new ManagePermissions(this);
            }
            this.contentPanel.Child = mngPermissions;
            SetLabelStyles("lblManagePermissions");
        }

        private void lblManageGroups_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (!loggedIn)
            {
                Login loginWindow = new Login();
                loggedIn = loginWindow.ShowDialog().Value;
                if (!loggedIn)
                {
                    return;
                }
            }
            if (mngGroups == null)
            {
                mngGroups = new ManageGroups(this);
            }
            this.contentPanel.Child = mngGroups;
            SetLabelStyles("lblManageGroups");
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            crtIdentity = null;
            updateProfile = null;
            regIdentity = null;
            mngPermissions = null;
            mngGroups = null;
            currentSelectedLink = null;
            this.contentPanel.Child = null;
            SetLabelStyles(string.Empty);
        }

        private void SetLabelStyles(string focusedLabelName)
        {
            Label label = null;
            foreach (UIElement uiElement in links.Children)
            {
                label = uiElement as Label;
                if (label != null && label.Name == focusedLabelName)
                {
                    label.Style = this.Resources["FocusedLabel"] as Style;
                    if (currentSelectedLink != null)
                    {
                        currentSelectedLink.Style = this.Resources["UnFocusedLabel"] as Style;
                    }
                    currentSelectedLink = label;
                }
            }
        }
    }
}
