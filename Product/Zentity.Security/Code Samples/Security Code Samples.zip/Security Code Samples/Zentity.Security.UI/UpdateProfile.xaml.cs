﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zentity.Security.AuthenticationProvider;
using Zentity.Security.Authentication;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for UpdateIdentity.xaml
    /// </summary>
    public partial class UpdateProfile : UserControl
    {
        private Main _parentWindow;
        private ZentityUser _currentUser;
        public UpdateProfile(Main parentWindow)
        {
            InitializeComponent();
            this._parentWindow = parentWindow;
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateUpdateProfileInput())
                {
                    ZentityUser user = CreateZentityUser();
                    if (user != null)
                    {
                        bool success = user.UpdateProfile();
                        if (success)
                        {
                            MessageBox.Show("User profile updated");
                        }
                        else
                        {
                            MessageBox.Show("Errors in updating user profile");
                        }
                    }
                }
            }
            catch (AuthenticationException ex)
            {
                MessageBox.Show(ex.Message);
                if (ex.InnerException != null)
                {
                    MessageBox.Show(ex.InnerException.Message);
                }
            }
        }

        private ZentityUser CreateZentityUser()
        {
            ZentityUser user = new ZentityUser();
            user.LogOnName = txtLogOn.Text;
            user.SetPassword(txtPassword.Password);
            if (!string.IsNullOrEmpty(txtQuestion.Text))
            {
                user.SetSecurityQuestion(txtQuestion.Text);
            }
            if (!string.IsNullOrEmpty(txtAnswer.Text))
            {
                user.SetAnswer(txtAnswer.Text);
            }
            if (!string.IsNullOrEmpty(txtCity.Text))
            {
                user.City = txtCity.Text;
            }
            if (!string.IsNullOrEmpty(txtCountry.Text))
            {
                user.Country = txtCountry.Text;
            }
            if (!string.IsNullOrEmpty(txtEmail.Text))
            {
                user.Email = txtEmail.Text;
            }
            if (!string.IsNullOrEmpty(txtFirstName.Text))
            {
                user.FirstName = txtFirstName.Text;
            }
            if (!string.IsNullOrEmpty(txtLastName.Text))
            {
                user.LastName = txtLastName.Text;
            }
            if (!string.IsNullOrEmpty(txtMiddleName.Text))
            {
                user.MiddleName = txtMiddleName.Text;
            }
            if (!string.IsNullOrEmpty(txtState.Text))
            {
                user.State = txtState.Text;
            }
            return user;
        }

        private bool ValidateUpdateProfileInput()
        {
            if (string.IsNullOrEmpty(txtLogOn.Text)
                || string.IsNullOrEmpty(txtPassword.Password))
            {
                MessageBox.Show("Please enter log on name and password");
                return false;
            }
            if (string.IsNullOrEmpty(txtAnswer.Text)
                && string.IsNullOrEmpty(txtCity.Text)
                && string.IsNullOrEmpty(txtCountry.Text)
                && string.IsNullOrEmpty(txtEmail.Text)
                && string.IsNullOrEmpty(txtFirstName.Text)
                && string.IsNullOrEmpty(txtLastName.Text)
                && string.IsNullOrEmpty(txtMiddleName.Text)
                && string.IsNullOrEmpty(txtQuestion.Text)
                && string.IsNullOrEmpty(txtState.Text))
            {
                MessageBox.Show("No property filled in for updating!");
                return false;
            }
            return true;
        }

        private void btnGetProfile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateGetProfileInput())
                {
                    _currentUser = ZentityUserManager.GetUserProfile(txtLogOn.Text, txtPassword.Password);
                    if (_currentUser != null)
                    {
                        ShowUserProperties();
                    }
                    else
                    {
                        MessageBox.Show("Errors in getting profile. Please verify whether the credentials entered are correct.");
                    }
                }
            }
            catch (AuthenticationException ex)
            {
                MessageBox.Show(ex.Message);
                if (ex.InnerException != null)
                {
                    MessageBox.Show(ex.InnerException.Message);
                }
            }
        }

        private void ShowUserProperties()
        {
            tblockFirstName.Text = _currentUser.FirstName;
            tblockMiddleName.Text = _currentUser.MiddleName;
            tblockLastName.Text = _currentUser.LastName;
            tblockEmail.Text = _currentUser.Email;
            tblockState.Text = _currentUser.State;
            tblockCountry.Text = _currentUser.Country;
            tblockCity.Text = _currentUser.City;
        }

        private bool ValidateGetProfileInput()
        {
            if (string.IsNullOrEmpty(txtLogOn.Text)
                || string.IsNullOrEmpty(txtPassword.Password))
            {
                MessageBox.Show("LogOn Name / Password missing");
                return false;
            }
            return true;
        }
    }
}
