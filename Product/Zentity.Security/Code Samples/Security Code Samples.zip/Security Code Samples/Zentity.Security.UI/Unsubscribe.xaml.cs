﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zentity.Security.Authentication;
using Zentity.Security.AuthenticationProvider;
using System.Configuration;
using Zentity.Security.Management;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for Unsubscribe.xaml
    /// </summary>
    public partial class Unsubscribe : UserControl
    {
        private AuthenticationManager _authenticationManager;
        private Main _parentWindow;

        public Unsubscribe(Main parentWindow)
        {
            InitializeComponent();
            this._parentWindow = parentWindow;
            string authenticationConnectionString = ConfigurationManager.ConnectionStrings["AuthenticationConnection"]
                .ConnectionString;
            _authenticationManager = new AuthenticationManager(authenticationConnectionString);
        }

        private void btnUnsubscribe_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateInput())
                {
                    bool success = ZentityUserManager.Unregister(txtLogOn.Text, txtPassword.Password);
                    if (success)
                    {
                        MessageBox.Show("Unsubscribed sucessfully", "Unsubscribe");
                    }
                    else
                    {
                        MessageBox.Show("Unsubscription not successful. Please verify the credentials", "Unsubscription errors");
                    }
                }
            }
            catch (AuthenticationException ex)
            {
                MessageBox.Show(ex.Message);
                if (ex.InnerException != null)
                {
                    MessageBox.Show(ex.InnerException.Message);
                }
            }
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrEmpty(txtLogOn.Text)
                || string.IsNullOrEmpty(txtPassword.Password))
            {
                MessageBox.Show("Please enter logon name and password.", "Input Required");
                return false;
            }
            return true;
        }
    }
}
