﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.ObjectModel;
using Zentity.Core;
using System.Configuration;
using Zentity.Extensions.Security.Authorization;
using System.Data.Objects;

namespace Zentity.Extensions.Security.UI
{
    public static class AuthorizationHelper
    {
        private static string authorizationConnStr;
        private static string authenticationConnStr;

        static AuthorizationHelper()
        {
            authorizationConnStr = ConfigurationManager.ConnectionStrings["AuthorizationStore"].ConnectionString;
            authenticationConnStr = ConfigurationManager.ConnectionStrings["AuthenticationStore"].ConnectionString;
        }

        

        public static void CreateIdentity()
        {
        }

       
    }

    public class ResourcePermissionMap
    {
        private string resource;

        public string Resource
        {
            get { return resource; }
            set { resource = value; }
        }
        private string permissions;

        public string Permissions
        {
            get { return permissions; }
            set { permissions = value; }
        }

    }

    public enum ResourceType
    {
        Identity,
        Group
    }
}
