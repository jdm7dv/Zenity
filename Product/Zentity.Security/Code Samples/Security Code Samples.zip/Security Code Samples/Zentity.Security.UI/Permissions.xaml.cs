﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Zentity.Security.Management;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for Permissions.xaml
    /// </summary>
    public partial class Permissions : Window
    {
        internal ResourcePermissionMap map;
        private bool isAddMode;

        public Permissions()
        {
            InitializeComponent();
            this.Title = "Add Permissions";
            this.isAddMode = true;
            map = new ResourcePermissionMap();
            txtResourceTitle.Focus();
        }

        public Permissions(ResourcePermissionMap map)
        {
            InitializeComponent();
            this.map = map;
            this.Title = "Edit Permissions";
            this.txtResourceTitle.Text = map.ResourceTitle;
            this.txtResourceTitle.IsReadOnly = true;
            SetBinding();
        }

        private void btnAddPermission_Click(object sender, RoutedEventArgs e)
        {
            string selectedPermission =
                ((ComboBoxItem)cmbPermissions.SelectedItem).Content.ToString();
            foreach (object item in lstPermissions.Items)
            {
                if (item.ToString() == selectedPermission)
                {
                    return;
                }
            }

            map.Permissions.Add(selectedPermission);
            lstPermissions.ItemsSource = null;
            SetBinding();
        }

        private void SetBinding()
        {
            Binding binding = new Binding("Permissions");
            binding.Source = this.map;
            lstPermissions.SetBinding(ListBox.ItemsSourceProperty, binding);
        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            if (this.isAddMode)
            {
                string resTitle = this.txtResourceTitle.Text.Trim();
                if (string.IsNullOrEmpty(resTitle))
                {
                    MessageBox.Show("Invalid Resource Title.", this.Title, MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                map.ResourceTitle = resTitle;                
            }
            this.DialogResult = true;
        }

        private void btnRemovePermission_Click(object sender, RoutedEventArgs e)
        {
            string selectedPermission =
                this.lstPermissions.SelectedItem.ToString();
            map.Permissions.Remove(selectedPermission);
            lstPermissions.ItemsSource = null;
            SetBinding();
        }
    }
}
