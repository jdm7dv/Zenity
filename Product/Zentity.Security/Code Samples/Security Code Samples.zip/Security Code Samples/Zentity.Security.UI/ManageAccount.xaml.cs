﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zentity.Security.Management;
using System.Configuration;
using Zentity.Security.AuthenticationProvider;
using Zentity.Security.Authentication;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for CreateIdentity.xaml
    /// </summary>
    public partial class ManageAccount : UserControl
    {
        private Main _parentWindow;
        private AuthenticationManager _authenticationManager;


        public ManageAccount(Main parentWindow)
        {
            InitializeComponent();
            this._parentWindow = parentWindow;
            string authenticationConnectionString = ConfigurationManager.ConnectionStrings["AuthenticationConnection"]
                .ConnectionString;
            _authenticationManager = new AuthenticationManager(authenticationConnectionString);
        }

        private void btnChangePassword_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateChangePasswordInput())
                {
                    bool success = ZentityUserManager.ChangePassword(txtLogOn.Text, txtCurrentPassword.Password,
                        txtNewPassword.Password);
                    if (success)
                    {
                        MessageBox.Show("Password changed");
                    }
                    else
                    {
                        MessageBox.Show("Password not changed. Please verify that the credentials entered are correct.");
                    }
                }
            }
            catch (AuthenticationException ex)
            {
                MessageBox.Show(ex.Message);
                if (ex.InnerException != null)
                {
                    MessageBox.Show(ex.InnerException.Message);
                }
            }
        }

        private bool ValidateChangePasswordInput()
        {
            if (string.IsNullOrEmpty(txtLogOn.Text)
                || string.IsNullOrEmpty(txtCurrentPassword.Password)
                || string.IsNullOrEmpty(txtNewPassword.Password)
                || string.IsNullOrEmpty(txtConfirmPassword.Password))
            {
                MessageBox.Show("All fields are mandatory");
                return false;
            }
            if (!string.Equals(txtNewPassword.Password, txtConfirmPassword.Password))
            {
                MessageBox.Show("New password not confirmed. Please re-enter.");
                return false;
            }
            return true;
        }

        private void btnForgotPassword_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateForgotPasswordInput())
            {
                string newSystemGeneratedPassword = ZentityUserManager.ForgotPassword(txtForgotPasswordLogOn.Text, txtQuestion.Text, txtAnswer.Text);
                if (!string.IsNullOrEmpty(newSystemGeneratedPassword))
                {
                    MessageBox.Show("Your new password is " + newSystemGeneratedPassword);
                }
                else
                {
                    MessageBox.Show("New password could not be generated. Please verify the security question and answer");
                }
            }
        }

        private bool ValidateForgotPasswordInput()
        {
            if (string.IsNullOrEmpty(txtForgotPasswordLogOn.Text)
                || string.IsNullOrEmpty(txtQuestion.Text)
                || string.IsNullOrEmpty(txtAnswer.Text))
            {
                MessageBox.Show("All fields are mandatory");
                return false;
            }
            return true;
        }
    }
}
