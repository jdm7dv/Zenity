﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Configuration;
using Zentity.Security.Management;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for RegisterIdentity.xaml
    /// </summary>
    public partial class RegisterIdentity : UserControl
    {
        private AuthorizationManager manager;
        private Main parentWindow;

        public RegisterIdentity(Main parentWindow)
        {
            InitializeComponent();
            this.parentWindow = parentWindow;
            string connStr = ConfigurationManager.ConnectionStrings["AuthorizationStore"].ConnectionString;
            manager = new AuthorizationManager(connStr);
            this.lstBoxGroups.ItemsSource = manager.GetAllGroups();
            txtIdentityName.Focus();
        }       

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            string identityName = txtIdentityName.Text.Trim();
            if(string.IsNullOrEmpty(identityName))
            {
                MessageBox.Show("Invalid Identity Name", "Register Identity", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            parentWindow.Cursor = Cursors.Wait;
            try
            {
                manager.RegisterIdentity(identityName);
                Collection<string> selectedGroups = new Collection<string>();
                foreach (object obj in lstBoxGroups.SelectedItems)
                {
                    selectedGroups.Add(obj.ToString());
                }
                ICollection<string> invalidGroups;
                manager.AssignGroupsToIdentity(identityName, selectedGroups, out invalidGroups);
                MessageBox.Show("Identity Registered.", "Register Identity", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (ArgumentException exp)
            {
                MessageBox.Show(exp.Message, "Register Identity", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                parentWindow.Cursor = Cursors.Arrow;
            }
        }

        private void btnUnRegister_Click(object sender, RoutedEventArgs e)
        {
            string identityName = txtIdentityName.Text.Trim();
            if (string.IsNullOrEmpty(identityName))
            {
                MessageBox.Show("Invalid Identity Name", "Register Identity", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            parentWindow.Cursor = Cursors.Wait;
            try
            {
                manager.RemoveIdentity(identityName);
                MessageBox.Show("Identity Removed.", "Register Identity", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (ArgumentException exp)
            {
                MessageBox.Show(exp.Message, "Register Identity", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                parentWindow.Cursor = Cursors.Arrow;
            }
        }
    }
}
