﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zentity.Security.Management;
using System.Configuration;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for ManageGroups.xaml
    /// </summary>
    public partial class ManageGroups : UserControl
    {
        private AuthorizationManager manager;
        private Main parentWindow;

        public ManageGroups(Main parentWindow)
        {
            InitializeComponent();
            this.parentWindow = parentWindow;
            string connStr = ConfigurationManager.ConnectionStrings["AuthorizationStore"].ConnectionString;
            manager = new AuthorizationManager(connStr);
            txtGroupName.Focus();
        }

        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            string groupName = txtGroupName.Text.Trim();
            if (string.IsNullOrEmpty(groupName))
            {
                MessageBox.Show("Invalid Group Name", "Manage Groups", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            parentWindow.Cursor = Cursors.Wait;
            try
            {
                manager.CreateGroup(groupName, txtGroupDescription.Text);
                MessageBox.Show("Group Created.", "Manage Groups", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (ArgumentException exp)
            {
                MessageBox.Show(exp.Message, "Manage Groups", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                parentWindow.Cursor = Cursors.Arrow;
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            string groupName = txtGroupName.Text.Trim();
            if (string.IsNullOrEmpty(groupName))
            {
                MessageBox.Show("Invalid Group Name", "Manage Groups", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            parentWindow.Cursor = Cursors.Wait;
            try
            {
                manager.DeleteGroup(groupName);
                MessageBox.Show("Group Deleted.", "Manage Groups", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (ArgumentException exp)
            {
                MessageBox.Show(exp.Message, "Manage Groups", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                parentWindow.Cursor = Cursors.Arrow;
            }
        }
    }
}
