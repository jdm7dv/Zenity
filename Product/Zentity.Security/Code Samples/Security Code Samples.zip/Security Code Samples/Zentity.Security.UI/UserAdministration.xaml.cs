﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zentity.Security.Authentication;
using Zentity.Security.AuthenticationProvider;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for UserAdministration.xaml
    /// </summary>
    public partial class UserAdministration : UserControl
    {
        public UserAdministration()
        {
            InitializeComponent();
        }

        private ZentityUserAdmin _admin;
        private IEnumerable<ZentityUser> _users;
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateLogInInput())
                {
                    _admin = new ZentityUserAdmin(txtLogOn.Text, txtPassword.Password);
                }

            }
            catch (AuthenticationException ex)
            {
                MessageBox.Show(ex.Message);
                if (ex.InnerException != null)
                {
                    MessageBox.Show(ex.InnerException.Message);
                }
            }
        }

        private bool ValidateLogInInput()
        {
            throw new NotImplementedException();
        }

        private void btnGetUsers_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateGetUsersInput())
                {
                    int startIndex = -1;
                    int endIndex = -1;
                    GetIndices(out startIndex, out endIndex);
                    if (startIndex != -1 && endIndex != -1)
                    {
                        _users = _admin.GetUsers(startIndex, endIndex);
                       
                    }
                }

            }
            catch (AuthenticationException ex)
            {
                MessageBox.Show(ex.Message);
                if (ex.InnerException != null)
                {
                    MessageBox.Show(ex.InnerException.Message);
                }
            }
        }

        private void GetIndices(out int startIndex, out int endIndex)
        {
            throw new NotImplementedException();
        }

        private bool ValidateGetUsersInput()
        {
            throw new NotImplementedException();
        }
    }
}
