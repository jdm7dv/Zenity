﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Zentity.Security.Management;
using System.Configuration;
using Zentity.Security.AuthenticationProvider;
using Zentity.Security.Authentication;

namespace Zentity.Security.UI
{
    /// <summary>
    /// Interaction logic for CreateIdentity.xaml
    /// </summary>
    public partial class UserRegistration : UserControl
    {
        private Main _parentWindow;
        private AuthenticationManager _authenticationManager;


        public UserRegistration(Main parentWindow)
        {
            InitializeComponent();
            this._parentWindow = parentWindow;
            string authenticationConnectionString = ConfigurationManager.ConnectionStrings["AuthenticationConnection"]
                .ConnectionString;
            _authenticationManager = new AuthenticationManager(authenticationConnectionString);
        }

        private void UserControl_Loaded(object sender, EventArgs e)
        {
        }

        //Validates inputs and registers the user
        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateInput())
                {
                    ZentityUser newUser = CreateZentityUser();
                    if (newUser != null)
                    {
                        bool success = newUser.Register();
                        if (success)
                        {
                            MessageBox.Show("User registered successfully");
                        }
                    }
                }
            }
            catch (AuthenticationException ex)
            {
                MessageBox.Show(ex.Message, "Error in Registration");
                if (ex.InnerException != null)
                {
                    MessageBox.Show(ex.InnerException.Message, "Error in Registration");
                }
            }
        }

        //Creates a new ZentityUser object and fills with property values (entered by the user in the form)
        private ZentityUser CreateZentityUser()
        {
            try
            {
                ZentityUser newUser = new ZentityUser();
                newUser.FirstName = txtFirstName.Text;
                newUser.LogOnName = txtLogOn.Text;
                newUser.Email = txtEmail.Text;
                newUser.SetPassword(txtPassword.Password);
                newUser.SetSecurityQuestion(txtQuestion.Text);
                newUser.SetAnswer(txtAnswer.Text);

                if (!string.IsNullOrEmpty(txtMiddleName.Text))
                {
                    newUser.MiddleName = txtMiddleName.Text;
                }
                if (!string.IsNullOrEmpty(txtLastName.Text))
                {
                    newUser.LastName = txtLastName.Text;
                }
                if (!string.IsNullOrEmpty(txtCity.Text))
                {
                    newUser.City = txtCity.Text;
                }
                if (!string.IsNullOrEmpty(txtState.Text))
                {
                    newUser.State = txtState.Text;
                }
                if (!string.IsNullOrEmpty(txtCountry.Text))
                {
                    newUser.Country = txtCountry.Text;
                }
                return newUser;
            }
            catch (AuthenticationException ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        //Calls methods for ensuring the following
        //1. All required properties are filled in
        //2. Email format is valid
        //3. LogOn name format is valid
        //4. Password entered in both boxes match
        private bool ValidateInput()
        {
            if (!RequiredPropertiesFilledIn())
            {
                return false;
            }
            if (!ValidateEmail())
            {
                return false;
            }
            if (!ValidateLogOn())
            {
                return false;
            }
            if (!ValidatePassword())
            {
                MessageBox.Show("Password not confirmed");
                return false;
            }
            return true;
        }

        
        private bool ValidatePassword()
        {
            if (!string.Equals(txtPassword.Password, txtConfirm.Password, StringComparison.Ordinal))
            {
                MessageBox.Show("Password not confirmed. Please reenter");
                return false;
            }
            return true;
        }

        private bool RequiredPropertiesFilledIn()
        {
            if (string.IsNullOrEmpty(txtLogOn.Text)
                || string.IsNullOrEmpty(txtPassword.Password)
                || string.IsNullOrEmpty(txtConfirm.Password)
                || string.IsNullOrEmpty(txtFirstName.Text)
                || string.IsNullOrEmpty(txtEmail.Text)
                || string.IsNullOrEmpty(txtQuestion.Text)
                || string.IsNullOrEmpty(txtAnswer.Text))
            {
                MessageBox.Show("Please fill in all required properties");
                return false;
            }
            return true;
        }

        //Validates that the email entered is in format a@b.c
        private bool ValidateEmail()
        {
            if (!char.IsLetter(txtEmail.Text[0])
                || !txtEmail.Text.Contains('@')
                || !txtEmail.Text.Contains('.')
                || txtEmail.Text.LastIndexOf('.') < txtEmail.Text.IndexOf('@')
                || txtEmail.Text.EndsWith("."))
            {
                MessageBox.Show("Email format not valid");
                return false;
            }
            return true;
        }

        //Checks whether the log on name starts with a letter and does not contain any special character.
        private bool ValidateLogOn()
        {
            if (!Char.IsLetter(txtLogOn.Text[0]))
            {
                MessageBox.Show("Logon name must start with a letter and cannot contain any special characters except _ and -");
                return false;
            }
            string specialChars = "~`!@#$%^&*()+={}[]:;'<>,.?/\\|\"";
            foreach (char ch in specialChars)
            {
                if (txtLogOn.Text.Contains(ch))
                {
                    MessageBox.Show("Logon name must start with a letter and cannot contain any special characters except _ and -");
                    return false;
                }
            }
            return true;
        }
    }
}
