﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zentity.Extensions.Security.UI
{
    public class AuthorizationHelperException : Exception
    {
        public AuthorizationHelperException(string message)
            : base(message) { }

        public AuthorizationHelperException(string message, Exception innerException)
            : base(message, innerException) { }
    }
}
