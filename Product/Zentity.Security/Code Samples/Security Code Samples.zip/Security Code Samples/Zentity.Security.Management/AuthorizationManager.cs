﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zentity.Core;
using Zentity.Security.Authorization;
using System.Collections.ObjectModel;

namespace Zentity.Security.Management
{
    public class AuthorizationManager
    {
        private string authorizationConnStr;        

        public AuthorizationManager(string authorizationConnStr)
        {
            this.authorizationConnStr = authorizationConnStr;            
        }       

        public IEnumerable<string> GetAllGroups()
        {
            ZentityContext context = new ZentityContext(authorizationConnStr);
            IEnumerable<string> groupNames = from grp in context.Resources.OfType<Group>()
                                            select grp.GroupName;
            return groupNames;
        }

        public void CreateGroup(string groupName, string description)
        {
            using (ZentityContext context = new ZentityContext(authorizationConnStr))
            {
                Group group = context.Resources.OfType<Group>().Where(res => res.GroupName == groupName).FirstOrDefault<Group>();
                if (group != null)
                {
                    throw new ArgumentException(string.Format("Group: {0} already exists.", groupName));
                }
                group = new Group();
                group.GroupName = groupName;
                group.Description = description;
                context.AddToResources(group);
                context.SaveChanges();
            }
        }

        public void DeleteGroup(string groupName)
        {
            using (ZentityContext context = new ZentityContext(authorizationConnStr))
            {
                Group group = context.Resources.OfType<Group>().Where(res => res.GroupName == groupName).FirstOrDefault<Group>();
                if (group == null)
                {
                    throw new ArgumentException(string.Format("Group: {0} does not exist.", groupName));
                }
                context.DeleteObject(group);
                context.SaveChanges();
            }
        }

        public void RegisterIdentity(string identityName)
        {
            using (ZentityContext context = new ZentityContext(authorizationConnStr))
            {
                if (context.Resources.OfType<Identity>().Where(res => res.IdentityName == identityName).Count() == 1)
                {
                    throw new ArgumentException(string.Format("Identity: {0} already exists.", identityName));
                }
                Identity identity = new Identity();
                identity.IdentityName = identityName;
                context.AddToResources(identity);
                context.SaveChanges();
                
                Relationship identityCanCreateResource = new Relationship();
                identityCanCreateResource.Subject = identity;
                identityCanCreateResource.Predicate = 
                    context.Predicates.Where(pred => pred.Name == AuthorizingPredicates.HasCreateAccess).First();
                identityCanCreateResource.Object = identity;
                context.AddToRelationships(identityCanCreateResource);
                context.SaveChanges();
            }
        }

        public void RemoveIdentity(string identityName)
        {
            using (ZentityContext context = new ZentityContext(authorizationConnStr))
            {
                Identity identity = 
                    context.Resources.OfType<Identity>().Where(res => res.IdentityName == identityName).FirstOrDefault<Identity>();
                if (identity == null)
                {
                    throw new ArgumentException(string.Format("Identity: {0} does not exist.", identityName));
                }
                context.DeleteObject(identity);
            }
        }

        public Guid GetResourceId(string resourceTitle)
        {
            using (ZentityContext context = new ZentityContext(authorizationConnStr))
            {
                return context.Resources.Where(res => res.Title == resourceTitle).
                    Select(res => res.Id).FirstOrDefault();
            }
        }

        public void AssignGroupsToIdentity(
                                    string identityName,
                                    IEnumerable<string> groups,
                                    out ICollection<string> invalidGroups)
        {
            invalidGroups = new Collection<string>();
            using (ZentityContext context = new ZentityContext(authorizationConnStr))
            {
                Identity identity =
                    context.Resources.OfType<Identity>().Where(res => res.IdentityName == identityName).
                    FirstOrDefault<Identity>();
                if (identity == null)
                {
                    throw new ArgumentException(string.Format("Identity: {0} does not exist.", identityName));
                }

                Group grp = null;
                Relationship rel = null;
                Predicate predicate = 
                    context.Predicates.Where(pred => pred.Name == AuthorizingPredicates.MemberOf).FirstOrDefault();
                foreach (string group in groups)
                {
                    grp = context.Resources.OfType<Group>().Where(res => res.GroupName == group).First<Group>();
                    if (grp == null)
                    {
                        invalidGroups.Add(group);
                    }
                    else
                    {
                        rel = new Relationship();
                        rel.Subject = identity;
                        rel.Predicate = predicate;
                        rel.Object = grp;
                        context.AddToRelationships(rel);
                    }
                }
                context.SaveChanges();
            }
        }        

       
        public void AssignPermissionsOnResource(
                                    string name,
                                    Guid resourceId,
                                    ICollection<string> permissions,
                                    ResourceType resType)
        {
            using (ZentityContext context = new ZentityContext(authorizationConnStr))
            {
                Guid id = Guid.Empty;
                Identity identity = null;
                Group group = null;
                Resource resource = null;

                switch (resType)
                {
                    case ResourceType.Identity:
                        identity = context.Resources.OfType<Identity>().Where(res => res.IdentityName == name).
                            FirstOrDefault<Identity>();
                        if (identity == null)
                        {
                            throw new ArgumentException(string.Format("Identity: {0} does not exist.", name));
                        }
                        id = identity.Id;
                        break;

                    case ResourceType.Group:
                        group = context.Resources.OfType<Group>().Where(res => res.GroupName == name).
                            FirstOrDefault<Group>();
                        if (group == null)
                        {
                            throw new ArgumentException(string.Format("Group: {0} does not exist.", name));
                        }
                        id = group.Id;
                        break;
                }

                resource = context.Resources.Where(res => res.Id == resourceId).First();
                if (resource == null)
                {
                    throw new ArgumentException(string.Format("Resource with Id: {0} does not exist.", resourceId));
                }

                IQueryable<Relationship> relationships = 
                    context.Relationships.Include("Predicate").
                        Where(rel => rel.Subject.Id == id && rel.Object.Id == resourceId);
                foreach (Relationship rel in relationships)
                {
                    if (!permissions.Contains(rel.Predicate.Name))
                    {
                        context.DeleteObject(rel);                        
                    }
                    else
                    {
                        permissions.Remove(rel.Predicate.Name);
                    }
                }

                Relationship newRel = null;
                foreach (string permission in permissions)
                {
                    newRel = new Relationship();
                    if (identity != null)
                    {
                        newRel.Subject = identity;
                    }
                    else if (group != null)
                    {
                        newRel.Subject = group;
                    }
                    newRel.Predicate = 
                        context.Predicates.Where(pred => pred.Name == permission).FirstOrDefault();
                    newRel.Object = resource;
                    context.AddToRelationships(newRel);                    
                }

                context.SaveChanges();
            }
        }

        public void AssignPermissionsOnResource(
                                    string name,
                                    string resourceTitle,
                                    ICollection<string> permissions,
                                    ResourceType resType)
        {
            using (ZentityContext context = new ZentityContext(authorizationConnStr))
            {
                Guid id = Guid.Empty;
                Identity identity = null;
                Group group = null;
                Resource resource = null;

                switch (resType)
                {
                    case ResourceType.Identity:
                        identity = context.Resources.OfType<Identity>().Where(res => res.IdentityName == name).FirstOrDefault<Identity>();
                        if (identity == null)
                        {
                            throw new ArgumentException(string.Format("Identity: {0} does not exist.", name));
                        }
                        id = identity.Id;
                        break;

                    case ResourceType.Group:
                        group = context.Resources.OfType<Group>().Where(res => res.GroupName == name).
                            FirstOrDefault<Group>();
                        if (group == null)
                        {
                            throw new ArgumentException(string.Format("Group: {0} does not exist.", name));
                        }
                        id = group.Id;
                        break;
                }
                resource = context.Resources.Where(res => res.Title == resourceTitle).First();
                if(resource == null)
                {
                    throw new ArgumentException(string.Format("Resource with title: {0} does not exist.", resourceTitle));
                }

                IQueryable<Relationship> relationships =
                    context.Relationships.Include("Predicate").
                        Where(rel => rel.Subject.Id == id && rel.Object.Id == resource.Id);
                foreach (Relationship rel in relationships)
                {
                    if (!permissions.Contains(rel.Predicate.Name))
                    {
                        context.DeleteObject(rel);
                    }
                    else
                    {
                        permissions.Remove(rel.Predicate.Name);
                    }
                }
                Relationship newRel = null;
                foreach (string permission in permissions)
                {
                    newRel = new Relationship();
                    if (identity != null)
                    {
                        newRel.Subject = identity;
                    }
                    else if (group != null)
                    {
                        newRel.Subject = group;
                    }
                    newRel.Predicate = context.Predicates.Where(pred => pred.Name == permission).FirstOrDefault();
                    newRel.Object = resource;
                    context.AddToRelationships(newRel);                    
                }
                context.SaveChanges();
            }
        }

        public ICollection<ResourcePermissionMap> GetResourcePermissionMap(
                                                                string name,
                                                                ResourceType resType)
        {
            return GetResourcePermissionMap(name, resType, 0, 0);
        }

        public ICollection<ResourcePermissionMap> GetResourcePermissionMap(
                                                                        string name,
                                                                        ResourceType resType,
                                                                        int startIndex,
                                                                        int pageSize)
        {
            using (ZentityContext context = new ZentityContext(authorizationConnStr))
            {
                Guid id = Guid.Empty;
                switch (resType)
                {
                    case ResourceType.Identity:
                        Identity identity = context.Resources.OfType<Identity>().Where(res => res.IdentityName == name).
                            FirstOrDefault<Identity>();
                        if (identity == null)
                        {
                            throw new ArgumentException(string.Format("Identity: {0} does not exist.", name));
                        }
                        id = identity.Id;
                        break;

                    case ResourceType.Group:
                        Group group = context.Resources.OfType<Group>().Where(res => res.GroupName == name).
                            FirstOrDefault<Group>();
                        if (group == null)
                        {
                            throw new ArgumentException(string.Format("Group: {0} does not exist.", name));
                        }
                        id = group.Id;
                        break;
                }

                var relationshipGroups =
                    context.Relationships.Where(rel => rel.Subject.Id == id).OrderByDescending(rel => rel.DateAdded).
                    Skip(startIndex).Take(pageSize).GroupBy(rel => rel.Object);

                Collection<ResourcePermissionMap> mapColl = new Collection<ResourcePermissionMap>();
                IQueryable<Relationship> relationships;
                ResourcePermissionMap map;
                foreach (var grp in relationshipGroups)
                {                    
                    relationships = context.Relationships.Include("Predicate").Where(rel => rel.Object.Id == grp.Key.Id);
                    map = new ResourcePermissionMap(grp.Key.Id);
                    map.ResourceTitle = grp.Key.Title;
                    map.ResourceId = grp.Key.Id;
                    
                    foreach (Relationship rel in relationships)
                    {
                        map.Permissions.Add(rel.Predicate.Name);                       
                    }                    
                    mapColl.Add(map);
                }
                return mapColl;
            }
        }
    }
}
