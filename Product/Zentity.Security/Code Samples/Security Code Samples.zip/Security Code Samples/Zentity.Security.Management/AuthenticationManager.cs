﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Zentity.Security.AuthenticationProvider;
using Zentity.Security.Authentication;
using System.IdentityModel.Tokens;

namespace Zentity.Security.Management
{
    /// <summary>
    /// This class provides wrapper methods to interact with the authentication API
    /// </summary>
    public class AuthenticationManager
    {
        private string _authenticationConnStr;

        /// <summary>
        /// Initializes AuthenticationManager object. 
        /// </summary>
        /// <param name="authenticationConnStr"></param>
        public AuthenticationManager(string authenticationConnStr)
        {
            this._authenticationConnStr = authenticationConnStr;            
        }

        /// <summary>
        /// Registers new user
        /// </summary>
        /// <param name="newUser">ZentityUser object with property values filled in</param>
        /// <returns>True if user registration succeeds.</returns>
        public bool RegisterUser(ZentityUser newUser)
        {
            bool isRegistered = newUser.Register();
            return isRegistered;
        }

        /// <summary>
        /// Updates user profile
        /// </summary>
        /// <param name="updatedUserObject">ZentityUser object filled in with logon name, password, and 
        /// properties to be updated</param>
        /// <returns>True if update is successful</returns>
        public bool UpdateUserProfile(ZentityUser updatedUserObject)
        {
            bool isUpdated = updatedUserObject.UpdateProfile();
            return isUpdated;
        }

        /// <summary>
        /// Updates log on name
        /// </summary>
        /// <param name="currentLogOn">Current log on name</param>
        /// <param name="newLogOn">New log on name</param>
        /// <param name="password">Password for the user account</param>
        /// <returns>True if update succeeds</returns>
        public bool UpdateLogOnName(string currentLogOn, string newLogOn, string password)
        {
            bool isLogOnUpdated = ZentityUserManager.UpdateLogOnName(currentLogOn, newLogOn, password);
            return isLogOnUpdated;
        }

        /// <summary>
        /// Changes password
        /// </summary>
        /// <param name="logOnName">LogOn name of the user</param>
        /// <param name="currentPassword">Current password</param>
        /// <param name="newPassword">New Password</param>
        /// <returns>True if password change is successful</returns>
        public bool ChangePassword(string logOnName, string currentPassword, string newPassword)
        {
            bool isPasswordUpdated = ZentityUserManager.ChangePassword(logOnName, currentPassword, newPassword);
            return isPasswordUpdated;
        }

        /// <summary>
        /// Generates a new strong password in case user forgets his password, and provides correct security question and answer.
        /// </summary>
        /// <param name="logOnName">LogOn name</param>
        /// <param name="securityQuestion">Security question entered when registering user account.</param>
        /// <param name="answer">Answer entered when registering user account.</param>
        /// <returns>New system generated password.</returns>
        public string ForgotPassword(string logOnName, string securityQuestion, string answer)
        {
            string newSystemGeneratedPassword = ZentityUserManager.ForgotPassword(logOnName, securityQuestion, answer);
            return newSystemGeneratedPassword;
        }

        /// <summary>
        /// Unsubscribes a user
        /// </summary>
        /// <param name="logOnName">LogOn Name of the user</param>
        /// <param name="password">User password</param>
        /// <returns>True if user is unregistered.</returns>
        public bool UnsubscribeUser(string logOnName, string password)
        {
            bool isUnsubscribed = ZentityUserManager.Unregister(logOnName, password);
            return isUnsubscribed;
        }

        /// <summary>
        /// Returns ZentityUser instance filled with property values from authentication store.
        /// </summary>
        /// <param name="logOnName">LogOn Name of the user</param>
        /// <param name="password">User password</param>
        /// <returns>ZentityUser object in case of success, null otherwise.</returns>
        public ZentityUser GetUserProfile(string logOnName, string password)
        {
            ZentityUser user = ZentityUserManager.GetUserProfile(logOnName, password);
            return user;
        }

        /// <summary>
        /// Verifies user credentials against those stored in the authentication store.
        /// </summary>
        /// <param name="userCredentials">UserNameSecurityToken is expected for ZentityAuthenticationProvider</param>
        /// <returns>Authenticated user token in case login succeeds, null otherwise.</returns>
        public AuthenticatedToken LogIn(SecurityToken userCredentials)
        {
            IAuthenticationProvider provider = AuthenticationProviderFactory.CreateAuthenticationProvider("ZentityAuthentication");
            if (provider != null)
            {
                AuthenticatedToken userToken = provider.Authenticate(userCredentials);
                return userToken;
            }
            return null;
        }

        /// <summary>
        /// Gets users in the given range, sorted by log on name.
        /// </summary>
        /// <param name="startIndex">Start index</param>
        /// <param name="endIndex">End index</param>
        /// <param name="adminName">Admin user name</param>
        /// <param name="adminPassword">Admin user password</param>
        /// <returns>List of users</returns>
        public IEnumerable<ZentityUser> GetUsers(int startIndex, int endIndex, string adminName, string adminPassword)
        {
            ZentityUserAdmin admin = new ZentityUserAdmin(adminName, adminPassword);
            return admin.GetUsers(startIndex, endIndex);
        }

        /// <summary>
        /// Gets all registered users
        /// </summary>
        /// <param name="adminName">Admin user name</param>
        /// <param name="adminPassword">Admin password</param>
        /// <returns>List of all users</returns>
        public IEnumerable<ZentityUser> GetUsers(string adminName, string adminPassword)
        {
            ZentityUserAdmin admin = new ZentityUserAdmin(adminName, adminPassword);
            return admin.GetUsers();
        }

        /// <summary>
        /// Gets all users from given start index, sorted on log on name
        /// </summary>
        /// <param name="startIndex">Start index</param>
        /// <param name="adminName">Admin user name</param>
        /// <param name="adminPassword">Admin password</param>
        /// <returns>List of users</returns>
        public IEnumerable<ZentityUser> GetUsers(int startIndex, string adminName, string adminPassword)
        {
            ZentityUserAdmin admin = new ZentityUserAdmin(adminName, adminPassword);
            return admin.GetUsers(startIndex);
        }
    }
}
