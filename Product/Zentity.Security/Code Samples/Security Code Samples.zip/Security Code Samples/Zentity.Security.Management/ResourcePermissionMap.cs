﻿// *********************************************************
// 
//     Copyright (c) Microsoft. All rights reserved.
//     This code is licensed under the Apache License, Version 2.0.
//     THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//     ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//     IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//     PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
// 
// *********************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using Zentity.Core;

namespace Zentity.Security.Management
{
    public class ResourcePermissionMap
    {
        private Guid resourceId;           
        private string resourceTitle;       
        private Collection<string> permissions = new Collection<string>();
        private string resourceStr;        

        public string PermissionsStr
        {
            get 
            {
                string permissionsStr = string.Empty;
                foreach (string permission in permissions)
                {
                    permissionsStr = string.Concat(permissionsStr, ";", permission);
                }
                permissionsStr = string.Format("Permissions: {0}", permissionsStr.TrimStart(';'));
                return permissionsStr; 
            }            
        }

        public string ResourceStr
        {
            get 
            {
                return string.Format("Resource Title: {0} Resource Id: {1}", resourceTitle, resourceId);                 
            }            
        }

        public Collection<string> Permissions
        {
            get { return permissions; }
            set { permissions = value; }
        }
        
        public string ResourceTitle
        {
            get { return resourceTitle; }
            set { resourceTitle = value; }
        }

        public Guid ResourceId
        {
            get { return resourceId; }
            set { resourceId = value; }
        }

        public ResourcePermissionMap() { }

        public ResourcePermissionMap(Guid resourceId)
        {
            this.resourceId = resourceId;
        }
    }

    public enum ResourceType
    {
        Identity,
        Group
    }
}
